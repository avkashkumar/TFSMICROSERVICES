package tfs.dfs.cdarservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import tfs.dfs.common.client.FulfillmentServiceClient;
import tfs.dfs.common.model.cdar.Cdar;
import tfs.dfs.common.model.cdar.CdarStatus;
import tfs.dfs.common.model.cdar.ProviderStatus;
import tfs.dfs.common.model.fulfillment.FulfillmentContext;
import tfs.dfs.common.model.fulfillment.Task;
import tfs.dfs.common.model.tenant.ServiceProvider;
import tfs.dfs.common.model.tenant.Tenant;
import tfs.dfs.common.rest.ErrorResponseEntity;
import tfs.dfs.multitenant.client.TenantServiceClient;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
public class CdarStatusController {
    private final static Logger logger = LoggerFactory.getLogger(CdarStatusController.class);
    @Resource(name = "multiTenantMongoTemplate")
    private MongoTemplate mongoTemplate;
    @Autowired
    private FulfillmentServiceClient fsClient;
    @Autowired
    private TenantServiceClient tenantServiceClient;

    @GetMapping(value = "/status/{cdarId}", produces = "application/json")
    public ResponseEntity retrieve(@PathVariable(required = false) String cdarId) {
        Cdar cdar = mongoTemplate.findById(cdarId, Cdar.class);
        if (cdar == null) {
            return new ErrorResponseEntity(String.format("Cdar with id %s was not found", cdarId), HttpStatus.NOT_FOUND);
        }
        FulfillmentContext context = fsClient.getFulfillmentContextByCdarId(cdar.getId());
        if(context == null) {
            return new ErrorResponseEntity(String.format("Cannot find FulfillmentContext with Cdar id %s (caseNo: %s)", cdar.getId(), cdar.getCaseNo()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        Tenant tenant = tenantServiceClient.getTenant();
        Map<String, ServiceProvider> spm = tenant.getServiceProviders().get(cdar.getSubject().getType());
        List<ProviderStatus> pstats = new ArrayList<>();
        List<Task> tasks = fsClient.getTasksForCdarId(cdar.getId());
        tasks.forEach(t->{
            ServiceProvider sp = tenantServiceClient.getServiceProvider(t.getAssignee());
            pstats.add(new ProviderStatus.Builder()
                        .cdarId(cdar.getId())
                        .contextId(context.getId())
                        .name(sp.getName())
                        .role(sp.getRole())
                        .state(t.getState())
                        .assigned(t.getAssigned())
                        .end(t.getCompleted())
                        .start(t.getStarted())
                        .providerId(sp.getId())
                        .taskId(t.getId())
                        .build());
        });
        CdarStatus cdarStatus = new CdarStatus.Builder()
                .cdarId(cdar.getId())
                .contextId(context.getId())
                .caseNo(cdar.getCaseNo())
                .activityNo(cdar.getActivityNo())
                .organization(cdar.getOrganization())
                .formDeliveryChannel(cdar.getFormDeliveryChannel())
                .subjectType(cdar.getSubject().getType())
                .initiatedOn(cdar.getInitiation())
                .subTaskCreatedOn(cdar.getSubTaskCreatedDate())
                .closedOn(cdar.getClosedOn())
                .state(cdar.getState())
                .receivedOn(cdar.getReceivedOn())
                .completedOn(cdar.getCompletedOn())
                .submittedForReviewOn(cdar.getSubmittedForReviewOn())
                .providerStatus(pstats)
                .build();
        return new ResponseEntity(cdarStatus, HttpStatus.OK);
    }
}
