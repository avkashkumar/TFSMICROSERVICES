package tfs.dfs.cdarservice;

import org.apache.http.client.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponentsBuilder;
import tfs.dfs.common.client.FulfillmentServiceClient;
import tfs.dfs.common.event.*;
import tfs.dfs.common.model.State;
import tfs.dfs.common.model.SubjectType;
import tfs.dfs.common.model.cdar.Cdar;
import tfs.dfs.common.model.customer.Customer;
import tfs.dfs.common.rest.ErrorResponseEntity;
import tfs.dfs.multitenant.CurrentTenantHolder;
import tfs.dfs.multitenant.dto.TenantConfiguration;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.Date;
import java.util.List;

import static tfs.dfs.common.rest.PaginatedResponseHelper.addNavigationHeaders;
import static tfs.dfs.common.rest.PaginatedResponseHelper.addTotalCountHeader;

@CrossOrigin
@RestController
public class CdarController {
    private final static Logger logger = LoggerFactory.getLogger(CdarController.class);
    @Resource(name = "multiTenantMongoTemplate")
    private MongoTemplate mongoTemplate;
    @Autowired
    private FulfillmentServiceClient fsClient;
    @Autowired  
    private KafkaTemplate<String, DfsEvent> dfsEventKafkaTemplate;
    @Autowired
    private String topicId;
    @Value("${event.source.id}")
    private String eventSourceId;
    /**
     * Initiate a new CDAR.
     * @param cdar
     * @return
     */
    @PostMapping(value = "/cdar", consumes = "application/json", produces = "application/json")
    public ResponseEntity create(@Valid @RequestBody Cdar cdar) {
        defaults(cdar);
        mongoTemplate.save(cdar);

        // now, create a context
        broadcastCdarInitiation(cdar);

        final HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(cdar.getId()).toUri());
        return new ResponseEntity(headers, HttpStatus.CREATED);
    }

    //creating new muti-tenant customer
    @PostMapping(value = "/customer", consumes = "application/json", produces = "application/json")
    public ResponseEntity create(@Valid @RequestBody Customer customer) {
        //defaults(customer);
        mongoTemplate.save(customer);

        // now, create a context
        broadcastCustomerInitiation(customer);

        final HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(customer.getCustomerId()).toUri());
        return new ResponseEntity(headers, HttpStatus.CREATED);
        //return "Customer Object saved successfully";
    }

    @GetMapping(value = "/cdar/{id}", produces = "application/json")
    public ResponseEntity retrieve(@PathVariable(required = false) String id) {
        Cdar cdar = mongoTemplate.findById(id, Cdar.class);
        if (cdar == null) {
            return new ErrorResponseEntity(String.format("Cdar with id %s was not found", id), HttpStatus.NOT_FOUND);
        }
        // TODO: send notification of CDAR creation
        return new ResponseEntity(cdar, HttpStatus.OK);
    }

    //Getting customer from customer collection using customer id.
    @GetMapping(value = "/customer/{id}", produces = "application/json")
    public ResponseEntity retrieveCustomer(@PathVariable(required = false) String id) {
        Customer customer = mongoTemplate.findById(id, Customer.class);
        if (customer == null) {
            return new ErrorResponseEntity(String.format("Customer with id %s was not found", id), HttpStatus.NOT_FOUND);
        }
        // TODO: send notification of CUSTOMER creation
        return new ResponseEntity(customer, HttpStatus.OK);
    }

    @GetMapping(value = "/cdar", produces = "application/json")
    /**
     * TODO: find a solution for this: 
     * public ResponseEntity retrieve(@RequestParam Map<String, String> allParams)
     *
     * Swagger currently doesn't support all HTTP request params collected into a Map; sucks.
     */
    public ResponseEntity search(@RequestParam(required = false, defaultValue = "") String id,
                                 @RequestParam(name="initiation", required = false) String initiationStr,
                                 @RequestParam(required = false) String caseNo,
                                 @RequestParam(required = false) String activityNo,
                                 @RequestParam(name="receivedOn", required = false) String receivedOnStr,
                                 @RequestParam(name="state", required = false) State state,
                                 @RequestParam(name="closedOn", required = false) String closedOnStr,
                                 @RequestParam(name="subject.type", required = false) SubjectType subjectType,
                                 @RequestParam(name="subject.firstName", required = false) String firstName,
                                 @RequestParam(name="subject.lastName", required = false) String lastName,
                                 @RequestParam(name="subject.middleName", required = false) String middleName,
                                 @RequestParam(name="subject.email", required = false) String email,
                                 @RequestParam(name="subject.phone", required = false) String phone,
                                 @RequestParam(name="subject.address.addressLine1", required = false) String address1,
                                 @RequestParam(name="subject.address.addressLine2", required = false) String address2,
                                 @RequestParam(name="subject.address.city", required = false) String city,
                                 @RequestParam(name="subject.address.state", required = false) String st,
                                 @RequestParam(name="subject.address.country", required = false) String country,
                                 @RequestParam(name="subject.address.zipcode", required = false) String zipcode,
                                 @RequestParam(defaultValue = "0") int page,
                                 @RequestParam(defaultValue = "64") int size,
                                 UriComponentsBuilder uriBuilder, HttpServletRequest request, HttpServletResponse response) {
        final Pageable pageable = PageRequest.of(page, size);
        final Query query = new Query();
        query.with(pageable);
        if (!StringUtils.isEmpty(id)) {
            query.addCriteria(Criteria.where("id").is(id));
        }
        if (!StringUtils.isEmpty(initiationStr)) {
            final Date initiation = DateUtils.parseDate(initiationStr);
            query.addCriteria(Criteria.where("initiation").is(initiation));
        }
        if (!StringUtils.isEmpty(caseNo)) {
            query.addCriteria(Criteria.where("caseNo").is(caseNo));
        }
        if (!StringUtils.isEmpty(activityNo)) {
            query.addCriteria(Criteria.where("activityNo").is(activityNo));
        }
        if (!StringUtils.isEmpty(firstName)) {
            query.addCriteria(Criteria.where("subject.firstName").is(firstName));
        }
        if (!StringUtils.isEmpty(lastName)) {
            query.addCriteria(Criteria.where("subject.lastName").is(lastName));
        }
        if (!StringUtils.isEmpty(middleName)) {
            query.addCriteria(Criteria.where("subject.middleName").is(middleName));
        }
        if (!StringUtils.isEmpty(email)) {
            query.addCriteria(Criteria.where("subject.email").is(email));
        }
        if (!StringUtils.isEmpty(phone)) {
            query.addCriteria(Criteria.where("subject.phone").is(phone));
        }
        if (!StringUtils.isEmpty(address1)) {
            query.addCriteria(Criteria.where("subject.address.address1").is(address1));
        }
        if (!StringUtils.isEmpty(address2)) {
            query.addCriteria(Criteria.where("subject.address.address2").is(address2));
        }
        if (!StringUtils.isEmpty(city)) {
            query.addCriteria(Criteria.where("subject.address.city").is(city));
        }
        if (!StringUtils.isEmpty(st)) {
            query.addCriteria(Criteria.where("subject.address.state").is(st));
        }
        if (!StringUtils.isEmpty(country)) {
            query.addCriteria(Criteria.where("subject.address.country").is(country));
        }
        if (!StringUtils.isEmpty(zipcode)) {
            query.addCriteria(Criteria.where("subject.address.zipcode").is(zipcode));
        }
        if (subjectType != null) {
            query.addCriteria(Criteria.where("subject.type").is(subjectType));
        }
        if (!StringUtils.isEmpty(receivedOnStr)) {
            final Date receivedOn = DateUtils.parseDate(receivedOnStr);
            query.addCriteria(Criteria.where("receivedOn").is(receivedOn));
        }
        if (state != null) {
            query.addCriteria(Criteria.where("state").is(state));
        }
        if (!StringUtils.isEmpty(closedOnStr)) {
            final Date closedOn = DateUtils.parseDate(closedOnStr);
            query.addCriteria(Criteria.where("closedOn").is(closedOn));
        }
        // see TODO above
        // allParams.forEach((k,v) -> query.addCriteria(Criteria.where(k).is(v)));
        final List<Cdar> cdars = mongoTemplate.find(query, Cdar.class);
        final long count =  mongoTemplate.count(query, Cdar.class);
        final Page<Cdar> cdarPage = PageableExecutionUtils.getPage(cdars, pageable, () -> count);
        request.getParameterMap().entrySet().forEach((e)-> { if(!e.getKey().equals("page") && !e.getKey().equals("size")) { uriBuilder.queryParam(e.getKey(), e.getValue());}});
        if(count > 1L) addNavigationHeaders(response, Cdar.class, page, cdarPage.getTotalPages(), size, uriBuilder);
        addTotalCountHeader(response, count);
        return new ResponseEntity(cdarPage.getContent(), HttpStatus.OK);
    }

    //Returning list of Customers back from Mongo Collection
    @GetMapping(value = "/customer", produces = "application/json")
    /**
     * TODO: find a solution for this:
     * public ResponseEntity retrieve(@RequestParam Map<String, String> allParams)
     *
     * Swagger currently doesn't support all HTTP request params collected into a Map; sucks.
     */
    public ResponseEntity searchCustomer(@RequestParam(required = false, defaultValue = "") String customerId,
                                 @RequestParam(name="subject.firstName", required = false) String firstName,
                                 @RequestParam(name="subject.lastName", required = false) String lastName,
                                 @RequestParam(name="subject.middleName", required = false) String middleName,
                                 @RequestParam(defaultValue = "0") int page,
                                 @RequestParam(defaultValue = "64") int size,
                                 UriComponentsBuilder uriBuilder, HttpServletRequest request, HttpServletResponse response) {
        final Pageable pageable = PageRequest.of(page, size);
        final Query query = new Query();
        query.with(pageable);
        if (!StringUtils.isEmpty(customerId)) {
            query.addCriteria(Criteria.where("customerId").is(customerId));
        }
        if (!StringUtils.isEmpty(firstName)) {
            query.addCriteria(Criteria.where("subject.firstName").is(firstName));
        }
        if (!StringUtils.isEmpty(lastName)) {
            query.addCriteria(Criteria.where("subject.lastName").is(lastName));
        }
        if (!StringUtils.isEmpty(middleName)) {
            query.addCriteria(Criteria.where("subject.middleName").is(middleName));
        }

        // see TODO above
        // allParams.forEach((k,v) -> query.addCriteria(Criteria.where(k).is(v)));
        final List<Customer> customers = mongoTemplate.find(query, Customer.class);
        final long count =  mongoTemplate.count(query, Customer.class);
        final Page<Customer> customerPage = PageableExecutionUtils.getPage(customers, pageable, () -> count);
        request.getParameterMap().entrySet().forEach((e)-> { if(!e.getKey().equals("page") && !e.getKey().equals("size")) { uriBuilder.queryParam(e.getKey(), e.getValue());}});
        if(count > 1L) addNavigationHeaders(response, Customer.class, page, customerPage.getTotalPages(), size, uriBuilder);
        addTotalCountHeader(response, count);
        return new ResponseEntity(customerPage.getContent(), HttpStatus.OK);
    }


    @PatchMapping(value = "/cdar/{id}", consumes = "application/json", produces = "application/json")
    public ResponseEntity update(@PathVariable String id, @RequestBody Cdar patch) {
        final Cdar cdar = mongoTemplate.findById(id, Cdar.class);
        if (cdar == null) {
            return new ErrorResponseEntity(String.format("Cdar with id %s was not found", id), HttpStatus.NOT_FOUND);
        }
        State state = cdar.getState();
        State patchedState = patch.getState();
        // TODO: move all these state manipulation to CdarService.
        if (patchedState != null) {
            if (state.equals(State.COMPLETED) || state.equals(State.EXPIRED) || state.equals(State.WITHDRAWN)) {
                // The only valid transitions from the above 3 states is to CLOSED.
                if(!patchedState.equals(State.CLOSED)) {
                    return new ErrorResponseEntity(String.format("Resource already in terminal state (%s)", state), HttpStatus.BAD_REQUEST);
                }
                else {
                    cdar.setState(State.CLOSED);
                    cdar.setClosedOn(new Date());
                    mongoTemplate.save(cdar);
                    broadcastCdarClosed(cdar);
                }
            }
            else if (patchedState.equals(State.IN_PROGRESS) && (state.equals(State.IN_PROGRESS) || state.equals(State.SUBMITTED))) {
                cdar.setState(patchedState);
                mongoTemplate.save(cdar);
                broadcastCdarInProgress(cdar);
            }
            else if (patchedState.equals(State.WITHDRAWN)) {
                cdar.setState(patchedState);
                cdar.setCompletedOn(new Date());
                mongoTemplate.save(cdar);
                broadcastCdarWithdrawn(cdar);
            }
            else if(cdar.getState().equals(State.IN_REVIEW) && patchedState.equals(State.PASSED_REVIEW)) {
                cdar.setState(patchedState);
                mongoTemplate.save(cdar);
                broadcastCcpaPassedReview(cdar);
            }
            else if(cdar.getState().equals(State.IN_REVIEW) && patchedState.equals(State.REJECTED)) {
                // CDAR has been REJECTED by validation process.
                cdar.setState(patchedState);
                mongoTemplate.save(cdar);
                broadcastCcpaRejected(cdar);
            }
            else {
                return new ErrorResponseEntity(String.format("Invalid modification requested (%s) on resource that is %s", patchedState, state), HttpStatus.BAD_REQUEST);
            }
        } else {
            return new ErrorResponseEntity("Missing patch set", HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }


    @PatchMapping(value = "/customer/{id}", consumes = "application/json", produces = "application/json")
    public ResponseEntity updateCustomer(@PathVariable String customerId, @RequestBody Customer patch) {
        final Customer customer = mongoTemplate.findById(customerId, Customer.class);
        if (customer == null) {
            return new ErrorResponseEntity(String.format("Customer with id %s was not found", customerId), HttpStatus.NOT_FOUND);
        }
        else{
            mongoTemplate.save(customer);
        }
       /* State state = customer.getState();
        State patchedState = patch.getState();
        // TODO: move all these state manipulation to CdarService.
        if (patchedState != null) {
            if (state.equals(State.COMPLETED) || state.equals(State.EXPIRED) || state.equals(State.WITHDRAWN)) {
                // The only valid transitions from the above 3 states is to CLOSED.
                if(!patchedState.equals(State.CLOSED)) {
                    return new ErrorResponseEntity(String.format("Resource already in terminal state (%s)", state), HttpStatus.BAD_REQUEST);
                }
                else {
                    customer.setState(State.CLOSED);
                    //customer.setClosedOn(new Date());
                    mongoTemplate.save(customer);
                    //broadcastCdarClosed(cdar);
                }
            }
            else if (patchedState.equals(State.IN_PROGRESS) && (state.equals(State.IN_PROGRESS) || state.equals(State.SUBMITTED))) {
                customer.setState(patchedState);
                mongoTemplate.save(customer);
                //broadcastCdarInProgress(customer);
            }
            else if (patchedState.equals(State.WITHDRAWN)) {
                customer.setState(patchedState);
                //customer.setCompletedOn(new Date());
                mongoTemplate.save(customer);
                //broadcastCdarWithdrawn(cdar);
            }
            else if(customer.getState().equals(State.IN_REVIEW) && patchedState.equals(State.PASSED_REVIEW)) {
                customer.setState(patchedState);
                mongoTemplate.save(customer);
                //broadcastCcpaPassedReview(cdar);
            }
            else if(customer.getState().equals(State.IN_REVIEW) && patchedState.equals(State.REJECTED)) {
                // CDAR has been REJECTED by validation process.
                customer.setState(patchedState);
                mongoTemplate.save(customer);
                //broadcastCcpaRejected(cdar);
            }
            else {
                return new ErrorResponseEntity(String.format("Invalid modification requested (%s) on resource that is %s", patchedState, state), HttpStatus.BAD_REQUEST);
            }
        } else {
            return new ErrorResponseEntity("Missing Missing URI template set", HttpStatus.BAD_REQUEST);
        }*/
        return new ResponseEntity("Customer Details updated Successfully.",HttpStatus.NO_CONTENT);
    }


    /**
     * Set a <code>CDAR</code> to its defaults.
     * @param cdar
     */
    private void defaults(Cdar cdar) {
        cdar.setId(null);
        cdar.setReceivedOn(new Date());
        cdar.setState(State.SUBMITTED);
        cdar.setClosedOn(null);
    }

   /* private void defaults(Customer customer) {
        customer.setCustomerId(null);
        customer.setReceivedOn(new Date());
        customer.setState(State.SUBMITTED);
        customer.setClosedOn(null);
    }*/

    private void broadcastCdarInitiation(Cdar cdar) {
        CdarInitiated event = new CdarInitiated();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setTenantId(tc.getAbbrevName());
        event.setSource(eventSourceId);
        event.setTimestamp(new Date());
        event.setCaseNo(cdar.getCaseNo());
        event.setCdarId(cdar.getId());
        event.setType(cdar.getSubject().getType());
        dfsEventKafkaTemplate.send(topicId, event);
    }

    private void broadcastCustomerInitiation(Customer customer) {
        CustomerInitiated event = new CustomerInitiated();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setCustomerId(customer.getCustomerId());
        event.setCustomerName(customer.getFirstName());
        event.setUpmURI("https://httpbin.org/{customerId}");
//        event.setCaseNo(cdar.getCaseNo());
//        event.setCdarId(cdar.getId());
//        event.setType(cdar.getSubject().getType());
        dfsEventKafkaTemplate.send(topicId, event);
    }

    private void broadcastCdarWithdrawn(Cdar cdar) {
        CdarWithdrawn event = new CdarWithdrawn();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setTenantId(tc.getAbbrevName());
        event.setSource(eventSourceId);
        event.setTimestamp(new Date());
        event.setCaseNo(cdar.getCaseNo());
        event.setCdarId(cdar.getId());
        dfsEventKafkaTemplate.send(topicId, event);
    }

    private void broadcastCdarInProgress(Cdar cdar) {
        CdarInProgress event = new CdarInProgress();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setTenantId(tc.getAbbrevName());
        event.setSource(eventSourceId);
        event.setTimestamp(new Date());
        event.setCaseNo(cdar.getCaseNo());
        event.setCdarId(cdar.getId());
        dfsEventKafkaTemplate.send(topicId, event);
    }

    private void broadcastCcpaPassedReview(Cdar cdar) {
        CcpaPassedReview event = new CcpaPassedReview();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setTenantId(tc.getAbbrevName());
        event.setSource(eventSourceId);
        event.setTimestamp(new Date());
        event.setCaseNo(cdar.getCaseNo());
        event.setCdarId(cdar.getId());
        dfsEventKafkaTemplate.send(topicId, event);
    }

    private void broadcastCcpaRejected(Cdar cdar) {
        CdarRejected event = new CdarRejected();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setTenantId(tc.getAbbrevName());
        event.setSource(eventSourceId);
        event.setTimestamp(new Date());
        event.setCaseNo(cdar.getCaseNo());
        event.setCdarId(cdar.getId());
        dfsEventKafkaTemplate.send(topicId, event);
    }

    private void broadcastCdarClosed(Cdar cdar) {
        CcpaClosed event = new CcpaClosed();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setTenantId(tc.getAbbrevName());
        event.setSource(eventSourceId);
        event.setTimestamp(new Date());
        event.setCaseNo(cdar.getCaseNo());
        event.setCdarId(cdar.getId());
        dfsEventKafkaTemplate.send(topicId, event);
    }

}
