package tfs.dfs.cdarservice.model;

public class Address1 {

    String doorNo;
    String addrLine;
    String city;

    public Address1(String doorNo, String addrLine, String city) {
        this.doorNo = doorNo;
        this.addrLine = addrLine;
        this.city = city;
    }

    public Address1(){}

    public String getDoorNo() {
        return doorNo;
    }

    public void setDoorNo(String doorNo) {
        this.doorNo = doorNo;
    }

    public String getAddrLine() {
        return addrLine;
    }

    public void setAddrLine(String addrLine) {
        this.addrLine = addrLine;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
