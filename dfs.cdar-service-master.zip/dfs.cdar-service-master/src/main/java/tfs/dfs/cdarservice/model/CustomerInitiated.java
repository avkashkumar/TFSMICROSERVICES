package tfs.dfs.cdarservice.model;

import tfs.dfs.common.event.BaseDfsEvent;
import tfs.dfs.common.event.CdarLifecycleEvent;

public class CustomerInitiated extends BaseDfsEvent implements CdarLifecycleEvent {
    private String customerId;
    private String customerName;
    private String upmURI;


    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getUpmURI() {
        return upmURI;
    }

    public void setUpmURI(String upmURI) {
        this.upmURI = upmURI;
    }

    @Override
    public String toString() {
        return "CustomerInitiated{" +
                "csutomerId='" + customerId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", upmURI='" + upmURI + '\'' +
                '}';
    }
}
