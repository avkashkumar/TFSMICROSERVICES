package tfs.dfs.cdarservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import tfs.dfs.common.model.State;
import tfs.dfs.common.model.cdar.Cdar;

import javax.annotation.Resource;
import java.util.Date;

@Service
public class CdarService {
    private final static Logger logger = LoggerFactory.getLogger(CdarService.class);
    @Resource(name = "multiTenantMongoTemplate")
    private MongoTemplate mongoTemplate;

    // TODO: merge this with the state manipulation logic in CdarController.update()!
    public void moveCdarState(String cdarId, State toState) {
        Cdar cdar = mongoTemplate.findById(cdarId, Cdar.class);
        if(cdar == null) {
            logger.error("Attempt to set CDAR with id " + cdarId + " to state " + toState);
            return;
        }
        cdar.setState(toState);
        if(toState == State.COMPLETED || toState == State.WITHDRAWN || toState == State.EXPIRED) {
            cdar.setCompletedOn(new Date());
        }
        else if(toState == State.IN_REVIEW) {
            cdar.setState(toState);
            cdar.setSubmittedForReviewOn(new Date());
        }
        else if(toState == State.CLOSED) {
            cdar.setClosedOn(new Date());
        }
        mongoTemplate.save(cdar);
    }
}
