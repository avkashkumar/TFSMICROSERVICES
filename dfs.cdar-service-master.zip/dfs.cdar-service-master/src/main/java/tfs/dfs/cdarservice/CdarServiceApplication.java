package tfs.dfs.cdarservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import tfs.dfs.cdarservice.model.Address1;
import tfs.dfs.common.event.*;
import tfs.dfs.common.model.State;
import tfs.dfs.common.model.cdar.Cdar;
import tfs.dfs.common.model.customer.Customer;
import tfs.dfs.event.CustomerEventHandler;
import tfs.dfs.event.DfsEventHandler;
import tfs.dfs.multitenant.CurrentTenantHolder;
import tfs.dfs.multitenant.InvalidOrMissingTenantException;
import tfs.dfs.multitenant.client.TenantServiceClient;
import tfs.dfs.multitenant.dto.TenantConfiguration;


import java.util.Arrays;

@SpringBootApplication(scanBasePackages = {"tfs.dfs"}, exclude = { MongoAutoConfiguration.class, MongoDataAutoConfiguration.class})
@EnableSwagger2
public class CdarServiceApplication {
	private final Logger logger = LoggerFactory.getLogger(CdarServiceApplication.class);
	@Autowired
	private CdarService cdarService;
	@Autowired
	private TenantServiceClient tenantServiceClient;


	@Bean
	public Docket swagger() {
		return new Docket(DocumentationType.SWAGGER_2)
				.globalOperationParameters(
						Arrays.asList(new ParameterBuilder()
								.name("X-Tenant-Id")
								.description("Multi-tenancy header")
								.modelRef(new ModelRef("string"))
								.parameterType("header")
								.required(true)
								.build())
				)
				.select()
				.apis(RequestHandlerSelectors.any())
				.paths(PathSelectors.any())
				.build();
	}
	// TODO move this to an 'eventhandler' class.
	@Bean
	public DfsEventHandler eventHandler() {
		return new DfsEventHandler() {
			@Override
			public void handle(DfsEvent event) {
				//logger.info("Customer Event : " + event.);
				logger.info("fetching tenant: " + event.getTenantId());
				// TODO: move this to interceptor code in the multitenant lib.
				TenantConfiguration tenantConfiguration = tenantServiceClient.getTenantByHeaderValue(event.getTenantId());
				if(tenantConfiguration == null) {
					throw new InvalidOrMissingTenantException("Received event " + event.getClass().getSimpleName() + " without a tenantId");
				}
				CurrentTenantHolder.set(tenantConfiguration);
				if(event instanceof CdarInProgress) {
					cdarService.moveCdarState(((CdarInProgress)event).getCdarId(), State.IN_PROGRESS);
				}
				else if(event instanceof CcpaInReview) {
					cdarService.moveCdarState(((CcpaInReview)event).getCdarId(), State.IN_REVIEW);
				}
				else if(event instanceof CcpaReportCompleted) {
					cdarService.moveCdarState(((CcpaReportCompleted)event).getCdarId(), State.COMPLETED);
				}
				CurrentTenantHolder.remove();
			}
		};
	}


	@Bean
	public CustomerEventHandler customerEventHandler() {
		return new CustomerEventHandler() {
			@Override
			public void handle(CustomerInitiated event) {
				logger.info("Customer Event : " + " Customer Id"+ event.getCustomerId());
				System.out.println("Customer Event : " + " Customer Id"+ event.getCustomerId());
				System.out.println("Customer Event : " + " Customer Id"+ event.getCustomerName());
				System.out.println("Customer Event : " + " Customer Id"+ event.getUpmURI());


				//update customer from event
				// POST request
				//POST/customer-update

//				HttpHeaders headers = new HttpHeaders();
//				headers.setContentType(MediaType.APPLICATION_JSON);

				// Create the CDAR.
//				HttpEntity<Cdar> createCdarRequest = new HttpEntity<Cdar>(cdar, headers);
//				ResponseEntity<String> createCdarResponse = restTemplate.postForEntity("/cdar", createCdarRequest, String.class);
//				assertThat(createCdarResponse).isNotNull();
//				assertThat(createCdarResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.CREATED);
//				assertThat(createCdarResponse.getHeaders().getLocation()).isNotNull();
//

				Address1 address1 = new Address1("12","abc","blr");

				final String URI="http://localhost:1212/updatedCustomer";
				HttpHeaders headers = new org.springframework.http.HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				//HttpEntity request = new HttpEntity<>(CustomerInitiated.class, headers);
				String hello="hello";

				RestTemplate restTemplate = new RestTemplate();

				HttpEntity request = new HttpEntity<>(Address1.class, headers);
				//restTemplate.postForObject(URI,address1,Address1.class);
//				restTemplate.exchange(URI, HttpMethod.POST,request, event);
//				restTemplate.postForObject(URI, request, CustomerInitiated.class);
//				restTemplate.exchange(URI,HttpMethod.POST,request,CustomerInitiated.class);
				restTemplate.exchange(URI,HttpMethod.POST,request,Address1.class);
				//String customerInitaiatedResult = restTemplate.postForObject(uris, "this is from cdar", String.class);





				//System.out.println("This is message from cdar rest template"+customerInitaiatedResult);

				//logger.info("fetching tenant: " + event.getTenantId());
				// TODO: move this to interceptor code in the multitenant lib.



//				TenantConfiguration tenantConfiguration = tenantServiceClient.getTenantByHeaderValue(event.getTenantId());
//				if(tenantConfiguration == null) {
//					throw new InvalidOrMissingTenantException("Received event " + event.getClass().getSimpleName() + " without a tenantId");
//				}
//				CurrentTenantHolder.set(tenantConfiguration);
////				if(event instanceof CdarInProgress) {
//					cdarService.moveCdarState(((CdarInProgress)event).getCdarId(), State.IN_PROGRESS);
//				}
//				else if(event instanceof CcpaInReview) {
//					cdarService.moveCdarState(((CcpaInReview)event).getCdarId(), State.IN_REVIEW);
//				}
//				else if(event instanceof CcpaReportCompleted) {
//					cdarService.moveCdarState(((CcpaReportCompleted)event).getCdarId(), State.COMPLETED);
//				}
				CurrentTenantHolder.remove();
			}
		};
	}


	public static void main(String[] args) {
		SpringApplication.run(CdarServiceApplication.class, args);
	}

}
