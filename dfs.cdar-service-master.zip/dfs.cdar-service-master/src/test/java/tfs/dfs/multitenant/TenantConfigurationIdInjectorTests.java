package tfs.dfs.multitenant;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import tfs.dfs.multitenant.dto.TenantConfiguration;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@Deprecated
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TenantConfigurationIdInjectorTests {
    private final static Logger logger = LoggerFactory.getLogger(TenantConfigurationIdInjectorTests.class);
    @Autowired
    private RestTemplate restTemplate;

    @Test
    @Ignore
    public void testInjection() {
        TenantConfiguration t = new TenantConfiguration();
        t.setName("My Mock TenantConfiguration");
        t.setAbbrevName("MOCK");
        t.setHeaderValue("MOCKY");
        t.setDbName("mockdb");
        t.setId("01234567890abcdef");
        CurrentTenantHolder.set(t);

        Map response = restTemplate.getForObject("https://httpbin.org/headers", Map.class);
        assertThat(response).isNotNull().isNotEmpty();
        Map headers = (Map) response.get("headers");
        assertThat(headers).isNotNull().isNotEmpty().containsKey("X-Tenant-Id");
        assertThat(headers.get("X-Tenant-Id")).isNotNull().asString().isEqualTo(t.getHeaderValue());
    }

}
