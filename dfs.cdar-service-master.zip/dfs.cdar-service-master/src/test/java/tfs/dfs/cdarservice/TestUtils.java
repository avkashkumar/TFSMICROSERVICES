package tfs.dfs.cdarservice;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import tfs.dfs.common.model.Address;
import tfs.dfs.common.model.Subject;
import tfs.dfs.common.model.SubjectType;

import java.util.Date;
import java.util.Map;

public class TestUtils {
    public static HttpHeaders setupMultiTenantHeaders() {
        return setupMultiTenantHeaders(new HttpHeaders());
    }

    public static HttpHeaders setupMultiTenantHeaders(HttpHeaders headers) {
        headers.add("X-Tenant-Id", "TMCC");
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }
    public static String generateTenant() {
        int r = RandomUtils.nextInt(0,98);
        return r < 33 ? "TMCC" : (r < 66 ? "TMS" : "TMIS");
    }

    public static String generateCaseNo() {
        return new StringBuilder("test-")
                .append(RandomStringUtils.randomAlphabetic(4)).append("-")
                .append(RandomStringUtils.randomAlphabetic(4)).append("-")
                .append(RandomStringUtils.randomAlphabetic(4)).append("-")
                .append(RandomStringUtils.randomAlphabetic(4))
                .toString();
    }
    public static String generateName() {
        return RandomStringUtils.randomAlphanumeric(8, 24);
    }

    public static SubjectType generateSubjectType() {
        return RandomUtils.nextBoolean() ? SubjectType.CONSUMER : SubjectType.CUSTOMER;
    }

    public static Address generateAddress() {
        final Address a = new Address();
        a.setAddressLine1(generateName());
        a.setAddressLine2(generateName());
        a.setCity(generateName());
        a.setCountry(generateName());
        a.setState(generateName());
        a.setZipCode(RandomStringUtils.randomNumeric(5));
        return a;
    }

    public static Subject generateSubject() {
        return generateSubject(null);
    }

    public static Subject generateSubject(String tenant) {
        final Subject r = new Subject();
        r.setType(generateSubjectType());
        r.setFirstName(generateName());
        r.setLastName(generateName());
        r.setMiddleName(generateName());
        r.setEmail(RandomStringUtils.randomAlphanumeric(2,32).concat("@").concat(RandomStringUtils.randomAlphanumeric(2,32).concat(".com")));
        r.setAddress(generateAddress());
        r.setPhone(RandomStringUtils.randomNumeric(10));
        final String t = StringUtils.isEmpty(tenant) ? "tmcc" : tenant;
        r.setSearchCriteria(t.equalsIgnoreCase("tmis") ? generateTmisCriteria() : generateTmccCriteria());
        return r;
    }

    public static Map<String,Object> generateTmccCriteria() {
        return Map.of(
                "DOB", new Date(),
                "SSN", RandomStringUtils.randomNumeric(9),
                "ACCTNO", RandomStringUtils.randomAlphanumeric(16).toUpperCase()
        );
    }

    public static Map<String,Object> generateTmisCriteria() {
        return Map.of(
                "APPLNO", RandomStringUtils.randomNumeric(16).toUpperCase(),
                "AGREENO", RandomStringUtils.randomNumeric(9).toUpperCase(),
                "VIN", RandomStringUtils.randomAlphanumeric(17).toUpperCase()
        );
    }

}
