package tfs.dfs.cdarservice;

import com.fasterxml.jackson.databind.SerializationFeature;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import tfs.dfs.common.model.cdar.Cdar;
import tfs.dfs.common.model.State;
import tfs.dfs.common.model.Subject;
import tfs.dfs.common.model.SubjectType;

import java.util.Date;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static tfs.dfs.cdarservice.TestUtils.*;
import static tfs.dfs.cdarservice.TestUtils.generateSubjectType;
import static tfs.dfs.common.model.State.IN_PROGRESS;
import static tfs.dfs.common.model.State.WITHDRAWN;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class EAS_631_CdarRetractionTests {
    @Autowired
    private TestRestTemplate restTemplate;
    private HttpHeaders headers;

    @Before
    public void setup() {
        this.headers = setupMultiTenantHeaders();
    }

    @Test
    public void isAbleToRetractSubmittedCdar() throws JSONException {
        final String caseNo = generateCaseNo();
        final Date initiation = new Date();
        final Subject subject = generateSubject();
        final SubjectType subjectType = generateSubjectType();
        final Map<String,Object> criteria = generateTmccCriteria();

        Cdar cdar = new Cdar();
        cdar.setCaseNo(caseNo);
        cdar.setInitiation(initiation);
        cdar.setSubject(subject);

        // Create the CDAR.
        HttpEntity<Cdar> createCdarRequest = new HttpEntity<Cdar>(cdar, headers);
        ResponseEntity<String> createCdarResponse = restTemplate.postForEntity("/cdar", createCdarRequest, String.class);
        assertThat(createCdarResponse).isNotNull();
        assertThat(createCdarResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.CREATED);
        assertThat(createCdarResponse.getHeaders().getLocation()).isNotNull();

        // ..now retrieve it.
        ResponseEntity<Cdar> retrieveResponse = restTemplate.exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.GET,new HttpEntity<>(headers), Cdar.class);
        assertThat(retrieveResponse).isNotNull();
        assertThat(retrieveResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(retrieveResponse.getBody()).isNotNull()
                .hasFieldOrPropertyWithValue("caseNo", caseNo)
                .hasFieldOrPropertyWithValue("initiation", initiation)
                .hasFieldOrPropertyWithValue("subject", subject)
                .hasFieldOrPropertyWithValue("state", State.SUBMITTED)
                .hasFieldOrProperty("receivedOn").isNotNull()
                .hasFieldOrPropertyWithValue("closedOn", null);
        // ..then withdraw
        JSONObject retraction = new JSONObject();
        retraction.put("state", WITHDRAWN);
        HttpEntity<String> retractCdarRequest = new HttpEntity<>(retraction.toString(), headers);
        ResponseEntity<String> retractionResponse = getRestTemplateWithPatchSupport().exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.PATCH, retractCdarRequest, String.class);
        assertThat(retractionResponse).isNotNull();
        assertThat(retractionResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.NO_CONTENT);
        assertThat(retractionResponse.getBody()).isNull();
    }

    @Test
    public void isAbleToRetractInProgressCdar() throws JSONException {
        final String caseNo = generateCaseNo();
        final Date initiation = new Date();
        final Subject subject = generateSubject();
        final SubjectType subjectType = generateSubjectType();
        final Map<String,Object> criteria = generateTmccCriteria();

        Cdar cdar = new Cdar();
        cdar.setCaseNo(caseNo);
        cdar.setInitiation(initiation);
        cdar.setSubject(subject);

        // Create the CDAR.
        HttpEntity<Cdar> createCdarRequest = new HttpEntity<Cdar>(cdar, headers);
        ResponseEntity<String> createCdarResponse = restTemplate.postForEntity("/cdar", createCdarRequest, String.class);
        assertThat(createCdarResponse).isNotNull();
        assertThat(createCdarResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.CREATED);
        assertThat(createCdarResponse.getHeaders().getLocation()).isNotNull();

        // ..now retrieve it.
        ResponseEntity<Cdar> retrieveResponse = restTemplate.exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.GET,new HttpEntity<>(headers), Cdar.class);
        assertThat(retrieveResponse).isNotNull();
        assertThat(retrieveResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(retrieveResponse.getBody()).isNotNull()
                .hasFieldOrPropertyWithValue("caseNo", caseNo)
                .hasFieldOrPropertyWithValue("initiation", initiation)
                .hasFieldOrPropertyWithValue("subject", subject)
                .hasFieldOrPropertyWithValue("state", State.SUBMITTED)
                .hasFieldOrProperty("receivedOn").isNotNull()
                .hasFieldOrPropertyWithValue("closedOn", null);

        // ..move to IN_PROGRESS
        JSONObject update = new JSONObject();
        update.put("state", IN_PROGRESS);
        HttpEntity<String> updateCdarRequest = new HttpEntity<>(update.toString(), headers);
        ResponseEntity<String> updateResponse = getRestTemplateWithPatchSupport().exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.PATCH, updateCdarRequest, String.class);
        assertThat(updateResponse).isNotNull();
        assertThat(updateResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.NO_CONTENT);
        assertThat(updateResponse.getBody()).isNull();

        // ..make sure it's been updated to IN_PROGRESS.
        ResponseEntity<Cdar> makeSureOfStatusUpdate = restTemplate.exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.GET,new HttpEntity<>(headers), Cdar.class);
        assertThat(makeSureOfStatusUpdate).isNotNull();
        assertThat(makeSureOfStatusUpdate.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(makeSureOfStatusUpdate.getBody()).isNotNull()
                .hasFieldOrPropertyWithValue("caseNo", caseNo)
                .hasFieldOrPropertyWithValue("initiation", initiation)
                .hasFieldOrPropertyWithValue("subject", subject)
                .hasFieldOrPropertyWithValue("state", IN_PROGRESS)
                .hasFieldOrProperty("receivedOn").isNotNull()
                .hasFieldOrPropertyWithValue("closedOn", null);

        // ..then withdraw
        JSONObject retraction = new JSONObject();
        retraction.put("state", WITHDRAWN);
        HttpEntity<String> retractCdarRequest = new HttpEntity<>(retraction.toString(), headers);
        ResponseEntity<String> retractionResponse = getRestTemplateWithPatchSupport().exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.PATCH, retractCdarRequest, String.class);
        assertThat(retractionResponse).isNotNull();
        assertThat(retractionResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.NO_CONTENT);
        assertThat(retractionResponse.getBody()).isNull();
    }

    @Test
    public void disallowsInvalidRetractionsFrom() throws JSONException {
        final String caseNo = generateCaseNo();
        final Date initiation = new Date();
        final Subject subject = generateSubject();
        final SubjectType subjectType = generateSubjectType();
        final Map<String,Object> criteria = generateTmccCriteria();

        Cdar cdar = new Cdar();
        cdar.setCaseNo(caseNo);
        cdar.setInitiation(initiation);
        cdar.setSubject(subject);

        // Create the CDAR.
        HttpEntity<Cdar> createCdarRequest = new HttpEntity<Cdar>(cdar, headers);
        ResponseEntity<String> createCdarResponse = restTemplate.postForEntity("/cdar", createCdarRequest, String.class);
        assertThat(createCdarResponse).isNotNull();
        assertThat(createCdarResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.CREATED);
        assertThat(createCdarResponse.getHeaders().getLocation()).isNotNull();

        // ..now retrieve it.
        ResponseEntity<Cdar> retrieveResponse = restTemplate.exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.GET,new HttpEntity<>(headers), Cdar.class);
        assertThat(retrieveResponse).isNotNull();
        assertThat(retrieveResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(retrieveResponse.getBody()).isNotNull()
                .hasFieldOrPropertyWithValue("caseNo", caseNo)
                .hasFieldOrPropertyWithValue("initiation", initiation)
                .hasFieldOrPropertyWithValue("subject", subject)
                .hasFieldOrPropertyWithValue("state", State.SUBMITTED)
                .hasFieldOrProperty("receivedOn").isNotNull()
                .hasFieldOrPropertyWithValue("closedOn", null);

        // ..move to WITHDRAWN
        JSONObject update = new JSONObject();
        update.put("state", WITHDRAWN);
        HttpEntity<String> updateCdarRequest = new HttpEntity<>(update.toString(), headers);
        ResponseEntity<String> updateResponse = getRestTemplateWithPatchSupport().exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.PATCH, updateCdarRequest, String.class);
        assertThat(updateResponse).isNotNull();
        assertThat(updateResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.NO_CONTENT);
        assertThat(updateResponse.getBody()).isNull();

        // ..make sure it's been updated to WITHDRAWN.
        ResponseEntity<Cdar> makeSureOfStatusUpdate = restTemplate.exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.GET,new HttpEntity<>(headers), Cdar.class);
        assertThat(makeSureOfStatusUpdate).isNotNull();
        assertThat(makeSureOfStatusUpdate.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(makeSureOfStatusUpdate.getBody()).isNotNull()
                .hasFieldOrPropertyWithValue("caseNo", caseNo)
                .hasFieldOrPropertyWithValue("initiation", initiation)
                .hasFieldOrPropertyWithValue("subject", subject)
                .hasFieldOrPropertyWithValue("state", WITHDRAWN)
                .hasFieldOrProperty("receivedOn").isNotNull()
                .hasFieldOrPropertyWithValue("closedOn", null);

        // ..now, try withdrawing again.
        JSONObject retraction = new JSONObject();
        retraction.put("state", WITHDRAWN);
        HttpEntity<String> retractCdarRequest = new HttpEntity<>(retraction.toString(), headers);
        ResponseEntity<Map> retractionResponse = null;
        try {
            // TODO: fix this; RestTemplate used below represents a returned 400 as an exception thrown to the caller.
            retractionResponse = getRestTemplateWithPatchSupport().exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.PATCH, retractCdarRequest, Map.class);
//            assertThat(retractionResponse).isNotNull();
//            assertThat(retractionResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.BAD_REQUEST);
//            assertThat(createCdarResponse.getBody()).isNotEmpty().containsPattern("^.*Resource already in terminal state (WITHDRAWN).*$");
        } catch (RestClientException e) {
            assertThat(e.toString().trim()).endsWith("400");
        }
    }

    /**
     * KLUDGE: Underlying HTTPUrlConnection used by the default RestTemplate doesn't support PATCH (known issue).
     * @see: https://stackoverflow.com/questions/41368762/resttemplate-and-patch-invalid
     */
    private RestTemplate getRestTemplateWithPatchSupport() {
        RestTemplate rt = new RestTemplate(new HttpComponentsClientHttpRequestFactory());
        MappingJackson2HttpMessageConverter jsonHttpMessageConverter = new MappingJackson2HttpMessageConverter();
        jsonHttpMessageConverter.getObjectMapper().configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        rt.getMessageConverters().add(jsonHttpMessageConverter);
        return rt;
    }
}
