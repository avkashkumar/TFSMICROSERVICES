package tfs.dfs.cdarservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import tfs.dfs.common.model.cdar.Cdar;
import tfs.dfs.common.model.State;
import tfs.dfs.common.model.Subject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
import static tfs.dfs.cdarservice.TestUtils.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class EAS_628_CdarInitiationTests {
    private final static Logger logger = LoggerFactory.getLogger(EAS_628_CdarInitiationTests.class);
    @Autowired
    private TestRestTemplate restTemplate;
    private HttpHeaders headers;
    private ObjectMapper mapper = new ObjectMapper();
    @Before
    public void setup() {
        this.headers = setupMultiTenantHeaders();
    }

    @Test
    public void isAbleToAcceptAValidCdar() throws JSONException, JsonProcessingException {
        Cdar cdar = new Cdar();
        cdar.setCaseNo(generateCaseNo());
        cdar.setInitiation(new Date());
        cdar.setSubject(generateSubject());

        HttpEntity<Cdar> request = new HttpEntity<Cdar>(cdar, headers);
        ResponseEntity<String> response = restTemplate.postForEntity("/cdar", request, String.class);
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isNotNull().isEqualTo(HttpStatus.CREATED);
        assertThat(response.getHeaders().getLocation()).isNotNull();
    }

    @Test
    public void isAbleToRetrieveCreatedCdar() throws JSONException, ParseException {
        final String caseNo = generateCaseNo();
        final Date initiation = new Date();
        final Subject subject = generateSubject();

        Cdar cdar = new Cdar();
        cdar.setCaseNo(caseNo);
        cdar.setInitiation(initiation);
        cdar.setSubject(subject);

        // Create the CDAR.
        HttpEntity<Cdar> createCdarRequest = new HttpEntity<Cdar>(cdar, headers);
        ResponseEntity<String> createCdarResponse = restTemplate.postForEntity("/cdar", createCdarRequest, String.class);
        assertThat(createCdarResponse).isNotNull();
        assertThat(createCdarResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.CREATED);
        assertThat(createCdarResponse.getHeaders().getLocation()).isNotNull();

        // Now retrieve it.
        ResponseEntity<Cdar> retrieveResponse = restTemplate.exchange(createCdarResponse.getHeaders().getLocation(), HttpMethod.GET,new HttpEntity<>(headers), Cdar.class);
        assertThat(retrieveResponse).isNotNull();
        assertThat(retrieveResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(retrieveResponse.getBody()).isNotNull()
                .hasFieldOrPropertyWithValue("caseNo", caseNo)
                .hasFieldOrPropertyWithValue("initiation", initiation)
                .hasFieldOrPropertyWithValue("subject", subject)
                .hasFieldOrPropertyWithValue("state", State.SUBMITTED)
                .hasFieldOrProperty("receivedOn").isNotNull()
                .hasFieldOrPropertyWithValue("closedOn", null);
    }

    @Test
    public void disallowsDuplicateCaseNos() throws JSONException {
        final String caseNo = generateCaseNo();
        final Date initiation = new Date();
        final Subject subject = generateSubject();

        Cdar cdar = new Cdar();
        cdar.setCaseNo(caseNo);
        cdar.setInitiation(initiation);
        cdar.setSubject(subject);

        // Create the CDAR.
        HttpEntity<Cdar> createCdarRequest = new HttpEntity<Cdar>(cdar, headers);
        ResponseEntity<String> createCdarResponse = restTemplate.postForEntity("/cdar", createCdarRequest, String.class);
        assertThat(createCdarResponse).isNotNull();
        assertThat(createCdarResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.CREATED);
        assertThat(createCdarResponse.getHeaders().getLocation()).isNotNull();

        // Try adding the same CDAR, again.
        HttpEntity<Cdar> createDupRequest = new HttpEntity<Cdar>(cdar, headers);
        ResponseEntity<String> createDupResponse = restTemplate.postForEntity("/cdar", createDupRequest, String.class);
        assertThat(createDupResponse).isNotNull();
        assertThat(createDupResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(createDupResponse.getBody()).isNotEmpty().containsPattern("^.*duplicate key error collection.*caseNo dup key:.*$");
    }

    @Deprecated
    @Test
    @Ignore
    public void disallowsBadSubjectType() throws JSONException {
        final String caseNo = generateCaseNo();
        final Date initiationDate = new Date();
        final String initiation = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS").format(initiationDate);
        final Subject subject = generateSubject();
        final String subjectType = generateName();
        JSONObject cdar = new JSONObject();
        cdar.put("caseNo", caseNo);
        cdar.put("initiation", initiation);
        cdar.put("subject", subject);
        cdar.put("subjectType", subjectType);

        // Create the CDAR.
        HttpEntity<String> createCdarRequest = new HttpEntity<String>(cdar.toString(), headers);
        ResponseEntity<String> createCdarResponse = restTemplate.postForEntity("/cdar", createCdarRequest, String.class);
        assertThat(createCdarResponse).isNotNull();
        assertThat(createCdarResponse.getStatusCode()).isNotNull().isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(createCdarResponse.getBody()).isNotEmpty().containsPattern("^.*JSON parse error: Cannot deserialize value of type.*value not one of declared Enum instance names.*$");
    }

}
