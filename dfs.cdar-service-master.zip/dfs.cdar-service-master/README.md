
Table of Contents
=================

  * [Current State](#current-state)
     * [Functionality](#functionality)
     * [Tooling](#tooling)
     * [Deployment](#deployment)
  * [Hacking on cdar-service](#hacking-on-cdar-service)
     * [Pre-Requisites](#pre-requisites)
     * [Dependencies](#dependencies)
        * [Build-time dependencies](#build-time-dependencies)
        * [Runtime service dependencies](#runtime-service-dependencies)
     * [Building and installing dependencies](#building-and-installing-dependencies)
     * [Building CDAR Service.](#building-cdar-service)
        * [Building a plain-vanila .jar](#building-a-plain-vanila-jar)
        * [Building a Docker image](#building-a-docker-image)
        * [Building and deploying to Heroku](#building-and-deploying-to-heroku)
     * [Booting the development environment](#booting-the-development-environment)
        * [Method 1: Using start-dependecies script](#method-1-using-start-dependecies-script)
        * [Method 2: Manually starting dependencies](#method-2-manually-starting-dependencies)
     * [Running unit tests](#running-unit-tests)
     * [Booting the microservice](#booting-the-microservice)
     * [Using SwaggerUI](#using-swaggerui)
     * [Generating Test Data](#generating-test-data)
        * [gen-cdars.sh](#gen-cdarssh)
        * [Examples](#examples)
  * [Deployment Notes](#deployment-notes)
     * [Environment settings](#environment-settings)

----
Welcome to the home of `cdarservice`, a microservice for the Data Fulfillment Service (DFS).

## Current State

![current state](./doc/image/dfs.cdar-service.current-state.png)

### Functionality
- [x] Basic `CDAR` model
- [x] Support basic `CRUD`
- [x] Rudimentary [multi-tenant configuration support](https://github.tfs.toyota.com/harpo/project.data-fulfillment-service/wiki/data-fulfillment-service.design#multi-tenancy-strategy).
    - [x] Support for `X-Tenant-Id`
    - [x] Integration with `TenantService`
- [ ] integration with `NotificationService`
- [x] Unit-tests

### Tooling
- [x] Tooling for test-data generation

### Deployment
- [x] Docker support
    - [x] Multi-tenant Mongodb
    - [x] Kafka 
- [x] Heroku support
    - [ ] Multi-tenant Mongodb
    - [x] Kafka 
- [ ] ICP support
    - [ ] Multi-tenant Mongodb
    - [ ] Kafka 

## Hacking on `cdar-service`
### Pre-Requisites
- JDK 12 (_required_)
- Maven 3 (_required_; reference version is `3.6.1` but don't foresee any issues with any 3.xx version)
- Docker (_recommended_)
    - used for running containerized versions of dependencies.
    - if you prefer to not use Docker, you'll need to provide instances of [these dependencies](#dependencies).

### Dependencies
CDAR service has the following dependencies.

#### Build-time dependencies
- DFS libraries
    - [dfs.common](https://github.tfs.toyota.com/harpo/dfs.common-lib)
    - [dfs.multitenant](https://github.tfs.toyota.com/harpo/dfs.multitenant-lib)
    - [dfs.event](https://github.tfs.toyota.com/harpo/dfs.event-lib)

Refer to [building local dependencies](#building-and-installing-dependencies), below.

#### Runtime service dependencies
- `FulfillmentService`
- `CCPAService`
- `TenantService`
- `MongoDB`
- `Kafka`

### Building and installing dependencies
If you haven't done so, install the DFS library dependencies, locally:
```bash
# build the common lib
$ git clone git@github.tfs.toyota.com:harpo/dfs.common-lib.git
$ cd dfs.common-lib
$ mvn clean package install
$ cd -

# build the event lib
$ git clone git@github.tfs.toyota.com:harpo/dfs.event-lib.git
$ cd dfs.event-lib
$ mvn clean package install
$ cd -

# build the multitenant lib
$ git clone git@github.tfs.toyota.com:harpo/dfs.multitenant-lib.git
$ cd dfs.multitenant-lib
$ mvn clean package install
$ cd -
```
Visit the DFS [common-lib](https://github.tfs.toyota.com/harpo/dfs.common-lib), [event-lib](https://github.tfs.toyota.com/harpo/dfs.event-lib) and [multitenant-lib](https://github.tfs.toyota.com/harpo/dfs.multitenant-lib) repositories for more information.

### Building CDAR Service.

#### Building a plain-vanila .jar

```bash
$ mvn clean package -DskipTests
```
_Remove `-DskipTests` if you intend to run unit tests._

#### Building a Docker image
```
$ mvn clean package dockerfile:build -DskipTests
```

#### Building and deploying to Heroku

```bash
$ mvn clean heroku:deploy -DskipTests
```
The above builds and deploys to Heroku as the app named in the property `heroku.app.name`.


### Booting the development environment

#### Method 1: Using `start-dependecies` script
```
[bashar@banshee cdarservice]$ ./.bin/start-dependencies.sh 
Stopping cdarservice_tenantservice_1 ... done
Stopping cdarservice_db_1            ... done
Removing cdarservice_tenantservice_1 ... done
Removing cdarservice_db_1            ... done
Removing network cdarservice_default
Creating network "cdarservice_default" with the default driver
Creating cdarservice_db_1 ... done
Creating cdarservice_tenantservice_1 ... done

[bashar@banshee cdarservice]$ 
```

#### Method 2: Manually starting dependencies

- __Step 1__. Shutdown previous instances if they exist.

```
[bashar@banshee cdarservice]$ docker-compose down
Stopping cdarservice_tenantservice_1 ... done
Stopping cdarservice_db_1            ... done
Removing cdarservice_tenantservice_1 ... done
Removing cdarservice_db_1            ... done
Removing network cdarservice_default
[bashar@banshee cdarservice]$ 

```

- __Step 2__. Start up dependencies

```
[bashar@banshee cdarservice]$ docker-compose up -d
Creating network "cdarservice_default" with the default driver
Creating cdarservice_db_1 ... done
Creating cdarservice_tenantservice_1 ... done
[bashar@banshee cdarservice]$ 

```

- __Step 3__. Populate the `tenantConfiguration` database

```$xslt
[bashar@banshee cdarservice]$ ./.bin/init-tenantConfiguration.sh 
[bashar@banshee cdarservice]$ 
```

### Running unit tests
```$xslt
TMS+NACIONS@PLP0024466 ~/dev/ccpa/services/dfs.cdar-service
$ mvn test 
[INFO] Scanning for projects...                                                                                                                 [INFO]
[INFO] ------------------------< tfs.dfs:cdarservice >-------------------------
[INFO] Building cdar-service 0.0.1-SNAPSHOT
[INFO] --------------------------------[ jar ]---------------------------------                                                                 [INFO]
[INFO] --- maven-resources-plugin:3.1.0:resources (default-resources) @ cdarservice ---                                                         [INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] Copying 1 resource                                                                                                                       [INFO] Copying 0 resource                                                                                                                       

-- SNIP --

[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running tfs.dfs.cdarservice.CdarServiceApplicationTests
16:29:59.024 [main] DEBUG org.springframework.test.context.junit4.SpringJUnit4ClassRunner - SpringJUnit4ClassRunner constructor called with [cla
ss tfs.dfs.cdarservice.CdarServiceApplicationTests]

-- SNIP --

16:30:00.233 [main] DEBUG org.springframework.test.context.support.TestPropertySourceUtils - Adding inlined properties to environment: {spring.j
mx.enabled=false, org.springframework.boot.test.context.SpringBootTestContextBootstrapper=true, server.port=-1}                                 
  .   ____          _            __ _ _                                                                                                          
/\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.7.RELEASE)

2019-08-28 16:30:01.159  INFO 33272 --- [           main] t.d.c.CdarServiceApplicationTests        : Starting CdarServiceApplicationTests on PLP
0024466 with PID 33272 (started by NACIONS in C:\Users\nacions\dev\ccpa\services\dfs.cdar-service)
2019-08-28 16:30:01.161  INFO 33272 --- [           main] t.d.c.CdarServiceApplicationTests        : No active profile set, falling back to defa
ult profiles: default

-- SNIP --

2019-08-28 16:30:23.867  INFO 33272 --- [       Thread-1] o.s.s.concurrent.ThreadPoolTaskExecutor  : Shutting down ExecutorService 'applicationT
askExecutor'
2019-08-28 16:30:23.877  INFO 33272 --- [       Thread-4] org.mongodb.driver.connection            : Closed connection [connectionId{localValue:3, serverValue:32}] to localhost:27017 because the pool has been closed.
[INFO]                                                                                                                                          
[INFO] Results:
[INFO]                                                                                                                                          
[WARNING] Tests run: 11, Failures: 0, Errors: 0, Skipped: 0
[INFO]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  33.349 s
[INFO] Finished at: 2019-08-28T09:30:25-07:00
[INFO] ------------------------------------------------------------------------

TMS+NACIONS@PLP0024466 ~/dev/ccpa/services/dfs.cdar-service
$  
```

### Booting the microservice

Start `cdar-service`:

```
[bashar@banshee cdarservice]$ mvn spring-boot:run        
[INFO] Scanning for projects...                                                                                                                            
[INFO]                                                                                                                                                     
[INFO] ------------------------< tfs.dfs:cdarservice >-------------------------                                                            
[INFO] Building cdar-service 0.0.1-SNAPSHOT                                                                                                                
[INFO] --------------------------------[ jar ]---------------------------------                                                                           

-- snip --

[INFO] Attaching agents: []

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.7.RELEASE)

2019-08-25 03:35:17.797  INFO 11051 --- [           main] t.d.cdarservice.CdarServiceApplication   : Starting CdarServiceApplication on banshee with PID 1$
051 (/home/bashar/dev/tfs/ccpa/dfs/microservices/cdarservice/target/classes started by bashar in /home/bashar/dev/tfs/ccpa/dfs/microservices/cdarservice)

-- snip --

2019-08-25 03:35:20.005  INFO 11051 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context pa
th ''
2019-08-25 03:35:20.009  INFO 11051 --- [           main] t.d.cdarservice.CdarServiceApplication   : Started CdarServiceApplication in 2.466 seconds (JVM r
unning for 2.653)

```

At this point, you can start issuing HTTP requests to service at `http://localhost:8080/cdar`

### Using SwaggerUI

Open a browser to `http://localhost:8080/swagger-ui.html`.  You should encounter a page like, below:

![cdar service swagger ui](./doc/image/cdarservice.swagger-ui.png)


### Generating Test Data

#### `gen-cdars.sh`
```$xslt
TMS+NACIONS@PLP0024466 ~/dev/ccpa/services/dfs.cdar-service/.bin
$ ./gen-cdars.sh

Usage: gen-cdars.sh (tmcc | tmis) (consumer | customer) [count]

```
The syntax is self-explanatory.  Please see the source for more options.

#### Examples
Generate a CDAR for TMCC tenantConfiguration and copy to clipboard.

```$xslt
TMS+NACIONS@PLP0024466 ~/dev/ccpa/services/dfs.cdar-service/.bin
$ TARGET=stdout ./gen-cdars.sh tmcc consumer | tee /dev/clipboard
{
  "caseNo": "f9c4-c978-2d92-6cb4-ddaa-91a5-f90d-12d1",
  "initiation": "2019-08-28",
  "subject": {
    "type": "CUSTOMER",
    "firstName" : "Halli",
    "lastName" : "McLeod",
    "email" : "halli.mcleod@broadbent.com",
    "address" : {
        "addressLine1" : "4881 Clement",
        "addressLine2" : "",
        "city" : "Wilkeson Alburtis",
        "state" : "CT",
        "country" : "USA",
        "zipCode" : "36916"
    },
    "phone": "(241) 366-4440",
    "searchCriteria": {
      "DOB": "1988-12-16",
      "SSN" : "382-86-7255",
      "ACCTNO": "BXFMYQL3G2BSXZPC"
    }
  }
}
```

## Deployment Notes

### Environment settings
The following settings are already taken cared of by the default configuration files and startup scripts.  However,
should the microservice be packaged differently, this section provides a guide on what needs configuring.

- __Server needs to execute in UTC timezone__.
    - This may be accomplished by configuring the host machine/container to operate in UTC.
    - Or, passing a JVM argument: `-Duser.timezone=UTC`

- __FulfillmentService endpoint__.
    - This can be changed by setting the following environment variables:
        - `FULFILLMENTSERVICE_PROTOCOL` - defaults to `http`
        - `FULFILLMENTSERVICE_HOST` - defaults to `localhost`
        - `FULFILLMENTSERVICE_PORT` - defaults to `18081`

- __TenantService endpoint__.
    - This can be changed by setting the following environment variables:
        - `TENANTSERVICE_PROTOCOL` - defaults to `http`
        - `TENANTSERVICE_HOST` - defaults to `localhost`
        - `TENANTSERVICE_PORT` - defaults to `18080`
        
- __CDAR Service MongoDb__.
    - Thsi can be changed by setting the following environment variables:
        - `CDARSERVICE_DB_HOST` - defaults to `localhost`
        - `CDARSERVICE_DB_PORT` - defaults to `27017`
