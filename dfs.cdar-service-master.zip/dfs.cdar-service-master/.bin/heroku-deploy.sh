#!/bin/bash

function build_lib () {
	local dir=$1
	echo "  building $(basename $dir)"
	cd ${dir}
	mvn ${CLEAN:+clean} package install 2>&1> /dev/null || echo "$(basename ${dir}) failed"
	cd - 2>&1>/dev/null
}

function build_app_heroku_deploy () {
	local dir=$1
	local app=$(basename $dir)
	echo "  building $app"
	cd ${dir}
	mvn ${CLEAN:+clean} heroku:deploy -DskipTests -Dheroku.app.name=${TENANT}-${app}${ENVIRONMENT:+-}${ENVIRONMENT} 2>&1> /dev/null || echo "$(basename ${dir}) failed"
	cd - 2>&1>/dev/null
}

function build_libs () {
	# build common libs
	echo "building libs.."
	while read line ; do
		build_lib $line
	done<<-EOF
lib/common
lib/event
lib/multitenant
EOF
}

function heroku_deploy () {
	# build and deploy microservices
	echo "building microservices.."
	parallel build_app_heroku_deploy {} <<-EOF
microservices/tenant
microservices/fulfillment
microservices/ccpa
microservices/cdar
microservices/forwarder
EOF
}

function is_up () {
    SERVICE=$1
    echo "$1 is "$(curl -qso -  "https://${SERVICE}.herokuapp.com/servicestatus" | egrep -q '^{"status":\"OK\"}$' && echo online || echo offline)
}

function servers_up () {
	parallel is_up ${TENANT}-{}${ENVIRONMENT:+-}${ENVIRONMENT} <<-EOF
tenant
fulfillment
ccpa
cdar
forwarder
EOF
}


export -f build_lib
export -f build_app_heroku_deploy
export -f heroku_deploy
export -f is_up
export -f servers_up


[[ $# = 0 ]] && {
    echo
    echo "syntax: $(basename $0) {tenant} [env]"
    echo
    exit 1
}
TENANT=$1
ENVIRONMENT=$2

export TENANT
export ENVIRONMENT

SAVEDIR=$(pwd)

cd $(dirname "$0")/../../..

build_libs
heroku_deploy &
wait
servers_up

cd "${SAVEDIR}"

