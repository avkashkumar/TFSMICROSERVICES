#!/usr/bin/env bash

[ "$*" = "" ] && {
	echo
	echo "Usage: $(basename $0) {case-no} [ ... {case-noXX} ]"
	echo
	exit 1
}	

CDARSERVICE_BASE=https://proxy.eip.tfscloud.com/ESP/dfs/cdar
TENANTS="TMCC TMIS"

for caseno in $* ; do
	for tenant in $TENANTS ; do
		CDARID=$(curl --noproxy '*' --insecure -Lsio -   -H 'X-TENANT-ID: '${tenant} -H 'Content-Type: application/json' -X GET ${CDARSERVICE_BASE}'/?caseNo='${caseno}|egrep '^\[\{\"id\":\"'| sed 's/^\[{\"id\":\"//g; s/\".*$//g')
		[ "$CDARID" != "" ] && {
			echo "withdrawing ${caseno} ($CDARID) in ${tenant}"
			curl -Lsio -  --insecure --noproxy '*' -H 'X-TENANT-ID: '${tenant} -H 'Content-Type: application/json' -X PATCH ${CDARSERVICE_BASE}'/'${CDARID} -d @-  <<EOF 
{
	"state" : "WITHDRAWN"
}
EOF
			break
		}
	done
done
