#!/bin/bash

function push_repo () {
	local dir=$1
	echo "pushing $(basename $dir)"
	cd ${dir}
	git push origin 2>&1> /dev/null || echo "$(basename ${dir}) failed"
	cd - 2>&1>/dev/null
}
export -f push_repo

SAVEDIR=$(pwd)
cd $(dirname "$0")/../../..
parallel push_repo {} <<-EOF
lib/common
lib/event
lib/multitenant
microservices/tenant
microservices/fulfillment
microservices/cdar
microservices/ccpa
microservices/notification
EOF

cd "${SAVEDIR}"

