#!/usr/bin/env bash

[[ $# -lt 1 ]] && {
    echo
    echo "syntax: $(basename $0) { build | teardown } [envname]"
    exit 1
}

TEAM=privacy-dfs
TENANT=${TENANT:-CHANGEME}
ENVIRONMENT=${2:-dev}
APP_SUPPORT=${TENANT}-support${ENVIRONMENT:+-}${ENVIRONMENT}
APP_TENANT=${TENANT}-tenant${ENVIRONMENT:+-}${ENVIRONMENT}
APP_CDAR=${TENANT}-cdar${ENVIRONMENT:+-}${ENVIRONMENT}
APP_FULFILLMENT=${TENANT}-fulfillment${ENVIRONMENT:+-}${ENVIRONMENT}
APP_CCPA=${TENANT}-ccpa${ENVIRONMENT:+-}${ENVIRONMENT}
APP_FORWARDER=${TENANT}-forwarder${ENVIRONMENT:+-}${ENVIRONMENT}

DB_NAME=${TENANT}-db${ENVIRONMENT:+-}${ENVIRONMENT}
KAFKA_NAME=${TENANT}-messaging${ENVIRONMENT:+-}${ENVIRONMENT}

# constants.
KAFKA_PLAN=basic-0
ONETRUST_APIKEY=eb79cdb52bc2ae1c007ff5d478122442

function apply_base_config() {
    local APPNAME=${1}
    heroku config:set CDARSERVICE_HOST=${APP_CDAR}.herokuapp.com -a ${APPNAME}
    heroku config:set CDARSERVICE_PORT=443 -a ${APPNAME}
    heroku config:set CDARSERVICE_PROTOCOL=https -a ${APPNAME}
    heroku config:set FULFILLMENTSERVICE_HOST=${APP_FULFILLMENT}.herokuapp.com -a ${APPNAME}
    heroku config:set FULFILLMENTSERVICE_PORT=443 -a ${APPNAME}
    heroku config:set FULFILLMENTSERVICE_PROTOCOL=https -a ${APPNAME}
    heroku config:set TENANTSERVICE_HOST=${APP_TENANT}.herokuapp.com -a ${APPNAME}
    heroku config:set TENANTSERVICE_PORT=443 -a ${APPNAME}
    heroku config:set TENANTSERVICE_PROTOCOL=https -a ${APPNAME}
}

function apply_cdar_config () {
    :
}

function apply_tenant_config () {
    :
}

function apply_fulfillment_config () {
    heroku config:set FS_RUN_APPROVAL_FOR_TENANTS=$(echo ${TENANT}|tr 'a-z' 'A-Z') -a ${APP_FULFILLMENT}
}

function apply_ccpa_config () {
    :
}

function apply_forwarder_config() {
    heroku config:set CCPASERVICE_HOST=${APP_CCPA}.herokuapp.com -a ${APP_FORWARDER}
    heroku config:set CCPASERVICE_PORT=443 -a ${APP_FORWARDER}
    heroku config:set CCPASERVICE_PROTOCOL=https -a ${APP_FORWARDER}
    heroku config:set ONETRUST_APIKEY=${ONETRUST_APIKEY} -a ${APP_FORWARDER}
}


function build() {
    # create support
    heroku apps:create -t ${TEAM} -a ${APP_SUPPORT}
    heroku addons:create mongolab -a ${APP_SUPPORT} --name=${DB_NAME} --wait
    # NOTE: zookeeper only available in `private spaces`.. won't hurt to specify here if outside a private space, though.
    heroku addons:create heroku-kafka:${KAFKA_PLAN} -a ${APP_SUPPORT} --name=${KAFKA_NAME} --enable-zookeeper
    heroku kafka:wait -a ${APP_SUPPORT}
    # TODO: deploy dummy-application

    # build kafka topics
    build_topics

    for each in ${APP_TENANT} ${APP_CDAR} ${APP_FULFILLMENT} ${APP_CCPA} ${APP_FORWARDER}; do
        app=${each/${TENANT}-/}
        app=${app/-${ENVIRONMENT}/}
        heroku apps:create -t ${TEAM} -a ${each}
        heroku addons:attach ${DB_NAME} -a ${each}
        #heroku addons:attach ${APP_SUPPORT}::MONGODB -a ${each}
        heroku addons:attach ${APP_SUPPORT}::KAFKA -a ${each}
        KAFKA_PREFIX=$(heroku config:get KAFKA_PREFIX -a ${each})
        heroku kafka:consumer-groups:create ${KAFKA_PREFIX}${app}-group -a ${each}
        apply_base_config ${each}
        apply_${app}_config
    done
}

function build_topics () {
    KAFKA_PREFIX=$(heroku config:get KAFKA_PREFIX -a ${APP_SUPPORT})
    heroku kafka:topics:create ${KAFKA_PREFIX}default-topic -a ${APP_SUPPORT}
}

function build_consumer_groups () {
    for each in ${APP_TENANT} ${APP_CDAR} ${APP_FULFILLMENT} ${APP_CCPA} ${APP_FORWARDER} ; do
        app=${each/${TENANT}-/}
        app=${app/-${ENVIRONMENT}/}
        KAFKA_PREFIX=$(heroku config:get KAFKA_PREFIX -a ${each})
        heroku kafka:consumer-groups:create ${KAFKA_PREFIX}${app}-group -a ${each}
    done
}

function config() {
    for each in ${APP_TENANT} ${APP_CDAR} ${APP_FULFILLMENT} ${APP_CCPA} ${APP_FORWARDER} ; do
        apply_base_config ${each}
    done
    apply_tenant_config
    apply_cdar_config
    apply_fulfillment_config
    apply_ccpa_config
    apply_forwarder_config
}

function teardown() {
    for each in ${APP_TENANT} ${APP_CDAR} ${APP_FULFILLMENT} ${APP_CCPA} ${APP_FORWARDER} ; do
        heroku apps:destroy -a ${each} --confirm=${each}
    done
    heroku apps:destroy -a ${APP_SUPPORT} --confirm=${APP_SUPPORT}
}

# quick-n-dirty rebuild
# TODO: change to something like 'build-except-support'
function qnd_rebuild() {
    for each in ${APP_TENANT} ${APP_CDAR} ${APP_FULFILLMENT} ${APP_CCPA} ${APP_FORWARDER}; do
        app=${each/${TENANT}-/}
        app=${app/-${ENVIRONMENT}/}
        heroku apps:create -t ${TEAM} -a ${each}
        heroku addons:attach ${APP_SUPPORT}::MONGODB -a ${each}
        heroku addons:attach tmis-support-dev::KAFKA -a ${each}
        KAFKA_PREFIX=$(heroku config:get KAFKA_PREFIX -a ${each})
        heroku kafka:consumer-groups:create ${KAFKA_PREFIX}${app}-group -a ${each}
        apply_base_config ${each}
        apply_${app}_config
    done
}

# quick-n-dirty teardown
# TODO: change to something like 'teardown-except-support'
function qnd_teardown() {
    for each in ${APP_TENANT} ${APP_CDAR} ${APP_FULFILLMENT} ${APP_CCPA} ${APP_FORWARDER} ; do
        heroku apps:destroy -a ${each} --confirm=${each}
    done
}

$*
