#!/usr/bin/env bash

# TODO: refactor and improve output target handling
# TODO: improve options handling.

SAMPLE_COUNT=${SAMPLE_COUNT:-64}
TENANT_ID=${TENANT_ID:-TMCC}
CDAR_SERVICE_ENDPOINT=${CDAR_SERVICE_ENDPOINT:-http://localhost:8080}
BIN_DIR=$(dirname "$(readlink -f "$0")")

source "${BIN_DIR}/common-lib.sh"

# Generate a TMCC CCPA request and send to ${CDAR_SERVICE_ENDPOINT}/cdar
function generate_tmcc() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local TENANT_ID=${2:-TMCC}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)
    CDAR_ID=$((curl --insecure --noproxy '*' -Lsi -H 'X-Tenant-Id: '${TENANT_ID} -H 'Content-Type: application/json' ${CDAR_SERVICE_ENDPOINT}/cdar -d @- | tac | sed '/^HTTP\/.* 201/q' | tac | egrep -i ^Location:| sed 's/^.*\///g'| tr -d '\n\r' )<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Toyota Motor Credit Corporation",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "DOB": "$(generate_dob)",
      "SSN" : "$(generate_ssn_last6)",
      "ACCTNO": "$(generate_acctno)"
    }
  }
}
EOF
)
    echo "${CDAR_ID}"
}

# Generate a TMCC CCPA request and output to stdout
function generate_tmcc_stdout() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)
    cat<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Toyota Motor Credit Corporation",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "DOB": "$(generate_dob)",
      "SSN" : "$(generate_ssn_last6)",
      "ACCTNO": "$(generate_acctno)"
    }
  }
}
EOF
}

# Generate a TMIS CCPA request and send to ${CDAR_SERVICE_ENDPOINT}/cdar
function generate_tmis() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local TENANT_ID=${2:-TMIS}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)

    CDAR_ID=$((curl --insecure --noproxy '*' -Lsi -H 'X-Tenant-Id: '${TENANT_ID} -H 'Content-Type: application/json' ${CDAR_SERVICE_ENDPOINT}/cdar -d @- | tac | sed '/^HTTP\/.* 201/q' | tac | egrep -i ^Location:| sed 's/^.*\///g'| tr -d '\n\r' )<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Toyota Motor Insurance Services",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "APPLNO": "$(generate_applno)",
      "AGREENO" : "$(generate_agreeno)",
      "VIN": "$(generate_vin_last8)"
    }
  }
}
EOF
)
    echo "${CDAR_ID}"
}

# Generate a TMIS CCPA request and output to stdout
function generate_tmis_stdout() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)
    cat<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Toyota Motor Insurance Services",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "APPLNO": "$(generate_applno)",
      "AGREENO" : "$(generate_agreeno)",
      "VIN": "$(generate_vin_last8)"
    }
  }
}
EOF
}

# Generate a MFS CCPA request and send to ${CDAR_SERVICE_ENDPOINT}/cdar
function generate_mfs() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local TENANT_ID=${2:-MFS}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)
    CDAR_ID=$((curl --insecure --noproxy '*' -Lsi -H 'X-Tenant-Id: '${TENANT_ID} -H 'Content-Type: application/json' ${CDAR_SERVICE_ENDPOINT}/cdar -d @- | tac | sed '/^HTTP\/.* 201/q' | tac | egrep -i ^Location:| sed 's/^.*\///g'| tr -d '\n\r' )<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Mazda Financial Services",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "SSN" : "$(generate_ssn_last6)"
    }
  }
}
EOF
)
    echo "${CDAR_ID}"
}

# Generate a MFS CCPA request and output to stdout
function generate_mfs_stdout() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)
    cat<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Mazda Financial Services",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "SSN" : "$(generate_ssn_last6)"
    }
  }
}
EOF
}

# Generate a MPP CCPA request and send to ${CDAR_SERVICE_ENDPOINT}/cdar
function generate_mpp() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local TENANT_ID=${2:-MPP}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)
    CDAR_ID=$((curl --insecure --noproxy '*' -Lsi -H 'X-Tenant-Id: '${TENANT_ID} -H 'Content-Type: application/json' ${CDAR_SERVICE_ENDPOINT}/cdar -d @- | tac | sed '/^HTTP\/.* 201/q' | tac | egrep -i ^Location:| sed 's/^.*\///g'| tr -d '\n\r' )<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Mazda Protection Plans",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "VIN" : "$(generate_vin_last8)",
      "contractNumber": "$(generate_agreeno)"
    }
  }
}
EOF
)
    echo "${CDAR_ID}"
}

# Generate a MPP CCPA request and output to stdout
function generate_mpp_stdout() {
    local SUBJECT_TYPE=${1:-CONSUMER}
    local FNAME=$(generate_first_name)
    local LNAME=$(generate_last_name)
    cat<<-EOF
{
  "caseNo": "$(generate_case_no)",
  "activityNo": "$(generate_activity_no)",
  "organization" : "Mazda Protection Plans",
  "formDeliveryChannel" : "$(generate_form_delivery_channel)",
  "initiation": "$(date +%Y-%m-%d)",
  "subTaskCreatedDate" : "$(date +%Y-%m-%d)",
  "subject": {
    "type": "${SUBJECT_TYPE}",
    "firstName" : "${FNAME}",
    "lastName" : "${LNAME}",
    $(maybe_generate_middle_name_property)
    "email" : "$(generate_email $FNAME $LNAME)",
    "address" : {
        "addressLine1" : "$(generate_address_line_one)",
        $(maybe_generate_address_line_two_property)
        "city" : "$(generate_city)",
        "state" : "$(generate_state)",
        "country" : "USA",
        "zipCode" : "$(generate_zipcode)"
    },
    "phone": "$(generate_phone_no)",
    "searchCriteria": {
      "VIN" : "$(generate_vin_last8)",
      "contractNumber": "$(generate_agreeno)"
    }
  }
}
EOF
}


[[ "$#" -lt 2 ]] && {
    echo
    echo "Usage: $(basename $0) (tmcc | tmis | mfs | mpp) (consumer | customer) [count] "
    echo
    exit 1
}

TENANT=$1
SUBJECT_TYPE=$2
COUNT=${3:-1}

# validate count
[[ $COUNT =~ ^[0-9]+$ ]] || {
    echo
    echo "Error: Invalid count (${COUNT})"
    echo
    exit 1
}

# validate subject type
case ${SUBJECT_TYPE} in
    consumer|customer)
        ;;
    *)
        echo
        echo "Error: Invalid subject type(${SUBJECT_TYPE})"
        echo
        exit 1
esac
SUBJECT_TYPE=$(echo ${SUBJECT_TYPE}|tr 'a-z' 'A-Z')

# execute by tenant
case ${TENANT} in
    tmcc)
        [[ ${TARGET} = stdout ]] && {
          [[ ${COUNT} = 1 ]] && {
            generate_tmcc_stdout $SUBJECT_TYPE
          } || {
            for i in `seq ${COUNT}` ; do
                generate_tmcc_stdout $SUBJECT_TYPE
            done
          }
        } || {
          for i in `seq ${COUNT}` ; do
              generate_tmcc $SUBJECT_TYPE
          done
        }
        ;;
    tmis)
        [[ ${TARGET} = stdout ]] && {
          [[ ${COUNT} = 1 ]] && {
            generate_tmis_stdout $SUBJECT_TYPE
          } || {
            for i in `seq ${COUNT}` ; do
                generate_tmis_stdout $SUBJECT_TYPE
            done
          }
        } || {
          for i in `seq ${COUNT}` ; do
              generate_tmis $SUBJECT_TYPE
          done
        }
        ;;
    mfs)
        [[ ${TARGET} = stdout ]] && {
          [[ ${COUNT} = 1 ]] && {
            generate_mfs_stdout $SUBJECT_TYPE
          } || {
            for i in `seq ${COUNT}` ; do
                generate_mfs_stdout $SUBJECT_TYPE
            done
          }
        } || {
          for i in `seq ${COUNT}` ; do
              generate_mfs $SUBJECT_TYPE
          done
        }
        ;;
    mpp)
        [[ ${TARGET} = stdout ]] && {
          [[ ${COUNT} = 1 ]] && {
            generate_mpp_stdout $SUBJECT_TYPE
          } || {
            for i in `seq ${COUNT}` ; do
                generate_mpp_stdout $SUBJECT_TYPE
            done
          }
        } || {
          for i in `seq ${COUNT}` ; do
              generate_mpp $SUBJECT_TYPE
          done
        }
        ;;
    *)
        echo ERROR
        exit
esac
