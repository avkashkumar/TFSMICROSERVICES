

db.getCollectionNames().forEach(function(collname) {
    var last_element = db[collname].find().sort({_id:-1}).limit(1);
    if(last_element.hasNext()){
        var next = last_element.next();
        if(next._id !== undefined && typeof next._id.getTimestamp == 'function'){
            printjson(collname + " >> "+next._id.getTimestamp());
        }else{
            print(collname + " undefined!! (getTimestamp N/A)")
        }
    }
});

db.getCollectionNames().map(function(collection){
    return { collection: collection, indexes: db[collection].getIndexes() };
});


var dfsTenants = [
    "tmcc"
    , "tmis"
    , "mfs"
    , "mpp"
    , "autofin"
];



// rebuild-unique-indexes.js
function rebuildCcpaUniqueIndexes() {
    db.cdars.createIndex({caseNo:1}, {unique: true});
    db.fulfillments.createIndex({taskId:1}, {unique: true});
}

function rebuildTenantUniqueIndexes() {
    db.serviceproviders.createIndex({name:1}, {unique: true});
    db.serviceproviders.createIndex({token:1}, {unique: true});
    db.tenants.createIndex({name:1}, {unique: true});
    db.tenants.createIndex({abbrevName:1}, {unique: true});
    db.tenants.createIndex({headerValue:1}, {unique: true});
}

use tmcc;
rebuildCcpaUniqueIndexes();
use tmis;
rebuildCcpaUniqueIndexes();
use mfs;
rebuildCcpaUniqueIndexes();
use mpp;
rebuildCcpaUniqueIndexes();
use autofin;
rebuildCcpaUniqueIndexes();
use tenant;
rebuildTenantUniqueIndexes();



// -- dumpindexes.js
function showCollectionIndexes() {
    printjson(db.getCollectionNames().map(function(collection){
        return { collection: collection, indexes: db[collection].getIndexes() };
    }));
}

rs.slaveOk();
print("tmcc");
use tmcc;
showCollectionIndexes();

print("tmis");
use tmis;
showCollectionIndexes();

print("mfs");
use mfs;
showCollectionIndexes();

print("mpp");
use mpp;
showCollectionIndexes();

print("autofin");
use autofin;
showCollectionIndexes();

// -- empty-collections.js

function emptyAllCollections() {
    db.getCollectionNames().forEach(function(collection){
        db[collection].remove({});
    });
}

use tmcc;
emptyAllCollections();
use tmis;
emptyAllCollections();
use mfs;
emptyAllCollections();
use mpp;
emptyAllCollections();
use autofin;
emptyAllCollections();


