#!/usr/bin/env bash


KAFKA_PREFIX=$(heroku config:get KAFKA_PREFIX)

heroku kafka:consumer-groups:create ${KAFKA_PREFIX}cdar-group -a cdar-s3
heroku kafka:consumer-groups:create ${KAFKA_PREFIX}fulfillment-group -a fulfillment-s3
heroku kafka:consumer-groups:create ${KAFKA_PREFIX}ccpa-group -a ccpa-s3



# attach to kafka
# attach to mongo
# scale up dyno to performance

#heroku ps:resize

heroku buildpacks:clear

VERSION=s3
DB_ADDON_ID=kafka-reticulated-50367
KAFKA_ADDON_ID=mongolab-cubed-42907

DB_CLIENTS=cdar fulfillment ccpa tenant
KAFKA_CLIENTS=cdar fulfillment ccpa

for each in ${DB_CLIENTS} ; do
    heroku addons:attach ${DB_ADDON_ID} -a ${each}-${VERSION}
done

for each in ${KAFKA_CLIENTS} ; do
    heroku addons:attach ${DB_ADDON_ID} -a ${each}-${VERSION}
done

