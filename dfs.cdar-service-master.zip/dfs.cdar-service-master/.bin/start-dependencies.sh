#!/usr/bin/env bash

[[ $(uname) =~ CYGWIN* ]] && {
  export CDAR_HOST=$(ipconfig | egrep -A 3 'Connection-specific DNS Suffix.*tfs.toyota.com'|egrep 'IPv4'|sed 's/.*: //g')
  export SLEEP_POST_DOCKER_DOWN=35
  export SLEEP_POST_DOCKER_UP=40
} || {
  export CDAR_HOST=$(ip route | egrep '/24.* scope link src .*metric '|cut -d\  -f9)
  export SLEEP_POST_DOCKER_DOWN=5
  export SLEEP_POST_DOCKER_UP=10
}

echo docker host: $CDAR_HOST
docker-compose down && \
sleep ${SLEEP_POST_DOCKER_DOWN} && \
docker ps -a | egrep -E '(cdar|fulfillment)_' | tr -s " "  |cut -d\  -f1 | xargs docker rm 2>&1>/dev/null
docker-compose up -d && \
sleep ${SLEEP_POST_DOCKER_UP} && \
$(dirname $0)/init-tenant.DEV.sh
