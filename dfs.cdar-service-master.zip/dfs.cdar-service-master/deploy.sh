#!/bin/bash
# get input parameters
ICP_URL=$1
ICP_NAMESPACE=$4
DOCKER_REGISTRY_URL=$ICP_URL:8500/$ICP_NAMESPACE
VERSION=$2
CURR_ENV=$3

echo "Running for ICP Cluster: " $ICP_URL
echo "Running for Env: " $CURR_ENV

# copy template to specific env file
rm -f dfscdar-$CURR_ENV.yaml* # change service name
cp dfscdar.yaml dfscdar-$CURR_ENV.yaml # change service name

# replace registry url in file
echo "Updating YAML with ICP Docker Registry: "$DOCKER_REGISTRY_URL

sed -i -e "s|<registry url>|$DOCKER_REGISTRY_URL|g" dfscdar-$CURR_ENV.yaml # change service name

echo "Updating YAML with Docker Tag: " $VERSION
sed -i -e "s|<version>|$VERSION|g" dfscdar-$CURR_ENV.yaml # change service name

# read property file
echo "Retrieving properties for Env: " $CURR_ENV

# update property file with env variables
PROPERTY_FILE="env/$CURR_ENV.properties"
awk 1 "$PROPERTY_FILE" | while IFS='=' read -r key value
do
    # Ampersands in sed strings have meaning, escape them!
    sed -i -e "s|<${key}>|${value//\&/\\\&}|g" dfscdar-$CURR_ENV.yaml # change service name
done

echo "Updated YAML with properties for Env: " $CURR_ENV

# clean up existing

/usr/local/bin/kubectl delete -f dfscdar-configmap.yaml --namespace=$ICP_NAMESPACE --ignore-not-found=true # change service name
/usr/local/bin/kubectl delete -f dfscdar-$CURR_ENV.yaml --namespace=$ICP_NAMESPACE --ignore-not-found=true # change service name

# redeploy

/usr/local/bin/kubectl create -f dfscdar-configmap.yaml --namespace=$ICP_NAMESPACE # change service name
/usr/local/bin/kubectl create -f dfscdar-$CURR_ENV.yaml --namespace=$ICP_NAMESPACE # change service name

rm -f dfscdar-$CURR_ENV.yaml-e # change service name
