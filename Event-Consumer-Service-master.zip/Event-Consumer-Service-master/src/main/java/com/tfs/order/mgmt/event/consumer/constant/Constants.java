package com.tfs.order.mgmt.event.consumer.constant;

/**
 * This class is responsible to holds the Constant for Customer Microservice
 * 
 * @author AmlanSaha
 */
public class Constants {

	public static final String KAFKA_GROUP_ID = "exchangeEvent";
}
