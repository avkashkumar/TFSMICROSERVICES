package com.tfs.order.mgmt.event.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventConsumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
