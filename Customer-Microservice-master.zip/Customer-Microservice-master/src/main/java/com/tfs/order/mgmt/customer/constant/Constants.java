package com.tfs.order.mgmt.customer.constant;

/**
 * This class is responsible to holds the Constant for Customer Microservice
 * 
 * @author AmlanSaha
 */
public class Constants {

	public static final String CUSTOMER_ID_KEY = "id";
}
