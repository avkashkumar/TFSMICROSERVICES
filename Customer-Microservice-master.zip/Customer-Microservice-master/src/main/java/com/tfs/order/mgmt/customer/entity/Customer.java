package com.tfs.order.mgmt.customer.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This Entity represents all the Customer attribute
 * 
 * @author AmlanSaha
 */
@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder({
    "id",
    "firstName",
    "lastName",
    "phoneNumber",
    "email",
    "address",
    "creditLimit",
    "version",
    "createdBy",
    "createdDate",
    "updatedBy",
    "updatedDate"
})
public class Customer implements Serializable
{

	private final static long serialVersionUID = 6938865787322676118L;
	
	@Id
    @JsonProperty("id")
    public String id;
    @JsonProperty("firstName")
    public String firstName;
    @JsonProperty("lastName")
    public String lastName;
    @JsonProperty("phoneNumber")
    public long phoneNumber;
    @JsonProperty("email")
    public String email;
    @JsonProperty("address")
    public Address address;
    @JsonProperty("creditLimit")
    public long creditLimit;
    @JsonProperty("version")
    public long version;
    @JsonProperty("createdBy")
    public String createdBy;
    @JsonProperty("createdDate")
    public Date createdDate;
    @JsonProperty("updatedBy")
    public String updatedBy;
    @JsonProperty("updatedDate")
    public Date updatedDate;
}
