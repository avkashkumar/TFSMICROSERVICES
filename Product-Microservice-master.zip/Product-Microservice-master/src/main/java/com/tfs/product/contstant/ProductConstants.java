/**
 *  @author AvkashKumar
 */
package com.tfs.product.contstant;

/**
 * @author AvkashKumar
 *
 */
public class ProductConstants {
	
	public static final String PRODUCT_ID_KEY = "_id";

}
