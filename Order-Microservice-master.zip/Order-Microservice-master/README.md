# Order-Microservice
This Repository holds the source and artifacts of Order Microservice. This Order Microservice exposes the reactive Rest endpoint for CRUD operation of Order entity.

## prerequisite

### Install JDK 8
<b>Step 1</b> <br />
Click <a href="https://www.oracle.com/java/technologies/javase-downloads.html">here</a> to Download JDK for java 8 latest version.
<br/><b>Step 2</b> <br />
Accept License Agreement. Download latest Java JDK(64 bit) of java for Windows.
<br/><b>Step 3</b> <br />
Once the download is complete, run the exe for install JDK. Click Next.
<br/><b>Step 4</b> <br />
Select the PATH for Java installation and click next.
<br/><b>Step 5</b> <br />
Once installation is complete click Close.
<br/><b>Step 6</b> <br />
Right Click on the My Computer and Select the properties.
<br/><b>Step 7</b> <br />
Click on advanced system settings.
<br/><b>Step 8</b> <br />
Click on Environment Variables.
<br/><b>Step 9</b> <br />
In “Environment variables” dialog, System variables, Clicks on the New... button and add a JAVA_HOME variable and point it to Java installation folder (For example - C:\Program Files\Java\jdk1.8.0_241)
<br/><b>Step 10</b> <br />
In system variables, find PATH, clicks on the Edit... button. In “Edit environment variable” dialog, clicks on the New button and add this %JAVA_HOME%\bin
<br/><b>Step 11</b> <br />
Done, start a new command prompt, type java –version. If everything goes fine, it will show the Java version.

### Install Apache Maven
<b>Step 1</b> <br />
Visit <a href="http://maven.apache.org/download.cgi">Maven official website</a>, download the Maven zip file, for example : apache-maven-3.6.3-bin.zip.
<br/><b>Step 2</b> <br />
Unzip it to a folder. For example - c:\Program Files\apache-maven-3.6.0
<br/><b>Step 3</b> <br />
Right Click on the My Computer and Select the properties.
<br/><b>Step 4</b> <br />
Click on advanced system settings.
<br/><b>Step 5</b> <br />
Click on Environment Variables.
<br/><b>Step 6</b> <br />
In “Environment variables” dialog, System variables, Clicks on the New... button and add a MAVEN_HOME variable and point it to Maven installation folder (For example - c:\Program Files\apache-maven-3.6.0)
<br/><b>Step 7</b> <br />
In system variables, find PATH, clicks on the Edit... button. In “Edit environment variable” dialog, clicks on the New button and add this %MAVEN_HOME%\bin
<br/><b>Step 8</b> <br />
Done, start a new command prompt, type mvn –version. If everything goes fine, it will show the Maven version.

### Install Mongo DB and Mongo Compass
Install Mongo DB and Mongo Compass by visiting <a href="https://docs.mongodb.com/manual/tutorial/install-mongodb-on-windows/">Mongo DB Official Website<a> and follow the steps mentioned there.

### Install Apache Kafka
<b>Step 1</b> <br />
Download and Install Apache Kafka Binaries from <a href="https://kafka.apache.org/downloads">Apache Kafka official download page</a> and extract it to for example - c:\kafka_2.12-2.4.1
<br/><b>Step 2</b> <br />
Here we will set up three node. Hence, for each node we require a separate server.properties in c:\kafka_2.12-2.4.1\config. 
By default we have one server.properties availble in c:\kafka_2.12-2.4.1\config, we will modify that and use it for node 1. For Node 2 and Node 3 we will create two new server.properties file.
<br/><b>Step 3</b> <br />
For Node 1, we will modify following two line in c:\kafka_2.12-2.4.1\config\server.properties file :
<i>broker.id=0</i>
<i>log.dirs=/tmp/kafka-logs</i>
<br/><b>Step 4</b> <br />
For Node 2, we will create a new file server1.properties c:\kafka_2.12-2.4.1\config and copy the content as it is from c:\kafka_2.12-2.4.1\config\server.properties file.
Finally, we will modify following two line in c:\kafka_2.12-2.4.1\config\server1.properties file :
<i>broker.id=1</i>
<i>log.dirs=/tmp/kafka-logs-1</i>
<br/><b>Step 5</b> <br />
For Node 3, we will create a new file server2.properties c:\kafka_2.12-2.4.1\config and copy the content as it is from c:\kafka_2.12-2.4.1\config\server.properties file.
Finally, we will modify following two line in c:\kafka_2.12-2.4.1\config\server2.properties file :
<i>broker.id=2</i>
<i>log.dirs=/tmp/kafka-logs-2</i>

### Install Zipkin
Fetch the latest release as a self-contained executable jar from <a href="https://search.maven.org/remote_content?g=io.zipkin&amp;a=zipkin-server&amp;v=LATEST&amp;c=exec">latest release</a>.


## Built With

* 	[Maven](https://maven.apache.org/) - Dependency Management
* 	[JDK 8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html) - Java™ Platform, Standard Edition Development Kit 
* 	[Spring Boot](https://spring.io/projects/spring-boot) - Framework to ease the bootstrapping and development of new Spring Applications
* 	[Reactive RESTful Web Service](https://docs.spring.io/spring-framework/docs/5.0.0.BUILD-SNAPSHOT/spring-framework-reference/html/web-reactive.html) -  Spring Webflux enable Reactive programming support for Web applications in Spring Framework that helps developers design, build, document, and consume RESTful Web services.
* 	[Spring Boot Admin](https://swagger.io/) - Open-Source software framework backed by a large ecosystem of tools that helps developers design, build, document, and consume RESTful Web services.
* 	[spring Netflix Eureka](https://spring.io/projects/spring-cloud-netflix) - Open-Source Spring Cloud Netflix provides Service Discovery (Eureka) and Client Side Load Balancing (Ribbon).
* 	[spring Netflix Zuul](https://spring.io/guides/gs/routing-and-filtering/) - Open-Source Netflix Zuul edge service library enables routing and filtering requests to a microservice application.
* 	[spring Cloud Sleuth](https://spring.io/projects/spring-cloud-sleuth) - Open-Source Spring Cloud Sleuth provides Spring Boot auto-configuration for distributed tracing.
* 	[spring Cloud Zipkin](https://spring.io/blog/2016/02/15/distributed-tracing-with-spring-cloud-sleuth-and-spring-cloud-zipkin) - Open-Source Zipkin is a distributed tracing system. uing Trace ID.
* 	[Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/) - Open-Source Spring Boot Actuator includes a number of additional features to help monitor and manage application.
* 	[spring-boot-devtools](https://docs.spring.io/spring-boot/docs/1.5.16.RELEASE/reference/html/using-boot-devtools.html) - Open-Source Spring Boot Devtool includes an additional set of tools that can make the application development experience a little more pleasant.
* 	[spring-kafka](https://spring.io/projects/spring-kafka) - The Spring for Apache Kafka (spring-kafka) project applies core Spring concep.ts to the development of Kafka-based messaging solutions.
* 	[Logger (Console, File)](http://logback.qos.ch/) - Open-Source Logback is a logging framework for Java applications.
* 	[NoSQL](https://www.mongodb.com/) - Open-Source NoSQL Database Management System.
* 	[git](https://git-scm.com/) - Free and Open-Source distributed version control system .
* 	[Lombok](https://projectlombok.org/) - Never write another getter or equals method again, with one annotation your class has a fully featured builder, Automate your logging variables, and much more.
* 	[Swagger](https://swagger.io/) - Open-Source software framework backed by a large ecosystem of tools that helps developers design, build, document, and consume RESTful Web services.


## External Tools Used

* [Postman](https://www.getpostman.com/) - API Development Environment (Testing Docmentation)


## Running the application locally

There are several ways to run a Spring Boot application on your local machine. One way is to execute the `main` method from your IDE.

- Download the zip or clone the Git repository.
- Unzip the zip file (if you downloaded one)
- Open Command Prompt and Change directory (cd) to folder containing pom.xml
- Open Eclipse 
   - File -> Import -> Existing Maven Project -> Navigate to the folder where you unzipped the zip
   - Select the project
- Choose the Spring Boot Application file (search for @SpringBootApplication)
- Right Click on the file and Run as Java Application

Alternatively you can use the [Spring Boot Maven plugin](https://docs.spring.io/spring-boot/docs/current/reference/html/build-tool-plugins-maven-plugin.html) like so:

```shell
mvn spring-boot:run
```

## Spring Boot Admin URL
http://localhost:8091/
<br />User Name: Admin
<br />Password: Admin

## Spring Eureka URL
http://localhost:8092/

## Swagger Documentation URL
http://localhost:8093/swagger-ui.html

## Zipkin URL
http://localhost:9411/zipkin
