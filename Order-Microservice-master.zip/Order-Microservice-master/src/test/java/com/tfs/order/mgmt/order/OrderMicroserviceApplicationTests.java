package com.tfs.order.mgmt.order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
