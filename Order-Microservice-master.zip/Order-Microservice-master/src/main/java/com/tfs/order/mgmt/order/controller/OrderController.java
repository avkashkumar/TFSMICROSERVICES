package com.tfs.order.mgmt.order.controller;

import org.springframework.web.bind.annotation.RestController;




@RestController
public class OrderController {

}
