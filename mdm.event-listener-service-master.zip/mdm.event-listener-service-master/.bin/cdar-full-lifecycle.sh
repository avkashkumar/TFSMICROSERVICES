#!/usr/bin/env bash
CURL_OPTS="--insecure --noproxy '*' -Ls -H X-Tenant-Id:MFS -H Content-Type:application/json"

function cip() {
    docker inspect -f "{{ range.NetworkSettings.Networks }}{{ .IPAddress }}{{ end }}" ${1} | head -n1
}

function curl_opts() {
    local tenant=$1
    echo "--insecure --noproxy '*' -Ls -H X-Tenant-Id:$(echo $1|tr a-z A-Z) -H Content-Type:application/json"
}

CDAR_SERVICE_ENDPOINT=${CDAR_SERVICE_ENDPOINT:-$(cip forwarder_cdarservice_1):8080}; export CDAR_SERVICE_ENDPOINT
FULFILLMENT_SERVICE_ENDPOINT=${FULFILLMENT_SERVICE_ENDPOINT:-$(cip forwarder_fulfillmentservice_1):8080} ; export FULFILLMENT_SERVICE_ENDPOINT

TENANT=${1:-mfs}

CDARID=$(./gen-cdars.sh ${TENANT} customer)
sleep 3s
#TASKID=$(curl $(curl_opts $TENANT) ${FULFILLMENT_SERVICE_ENDPOINT}'/task?state=NOT_STARTED&size=1' | jq -r '.[0].id?')
TASKID=$(curl $(curl_opts $TENANT) ${FULFILLMENT_SERVICE_ENDPOINT}'/task?state=NOT_STARTED&cdarId='${CDARID} | cut -d, -f1 | sed 's/^.*:\"//g; s/\"$//g')


if [ $TENANT = mfs ] ; then {
    curl $(curl_opts $TENANT)  -i  ${FULFILLMENT_SERVICE_ENDPOINT}'/fulfillment?taskId='${TASKID}'&closeTaskOnSuccess=true' -X POST -d @-<<-EOF
{
    "requestId" : "${TASKID}"
    , "matched" : "true"
}
EOF
}
elif [ $TENANT = mpp ] ; then
    curl $(curl_opts $TENANT) -i ${FULFILLMENT_SERVICE_ENDPOINT}'/fulfillment?taskId='${TASKID}'&closeTaskOnSuccess=true' -X POST -d @-<<-EOF
{
    "requestId": "${TASKID}",
    "matched" : "true",
    "comment": "",
    "name": ["ABC DEF"],
    "claimNumber": ["FGT3456789"],
    "contractNumber": ["67589"],
    "countryOfResidence": ["USA"],
    "homePhoneNumber": ["3456789098","123-345-5643"],
    "postalAddress": ["LENIN SARANI ,DHARMATALA,US,12345", "SARANI LENIN ,ORANGE,US,90534"],
    "vehicleClass": ["3-UL"],
    "vehicleMake": ["TOYOTA"],
    "vehicleMileage": ["23000"],
    "vehicleModel": ["CAMRY"],
    "vehicleSize": ["MID-SIZE CAR"],
    "vehicleTrim": ["PREMIUM"],
    "vehicleType": ["C"],
    "vehicleVIN": ["2345RTY9876YT34566"],
    "vehicleYear": ["2014"]
    }
EOF
elif [ $TENANT = tmcc ] ; then
    curl $(curl_opts $TENANT)  -i  ${FULFILLMENT_SERVICE_ENDPOINT}'/fulfillment?taskId='${TASKID}'&closeTaskOnSuccess=true' -X POST -d @-<<-EOF
    {
        "matched" : "true"
    }
EOF
elif [ $TENANT = tmis ] ; then
    curl $(curl_opts $TENANT)  -i  ${FULFILLMENT_SERVICE_ENDPOINT}'/fulfillment?taskId='${TASKID}'&closeTaskOnSuccess=true' -X POST -d @-<<-EOF
    {
    "requestId": "${TASKID}",
    "comment": "no comments",
    "name": ["Marrietta Stoffel"],
    "agreementNumber": ["OZ3E2USIYNRFBSBF"],
    "claimNumber": ["BOGUSCLAIMNO-1"],
    "contractNumber": ["BOGUSCONTRACTNO-1"],
    "countryOfResidence": ["USA"],
    "homePhoneNumber": ["(399) 359-1151" ],
    "postalAddress": ["6795 Lorne Pkwy, Odanah Enon, CO, USA 24845"],
    "vehicleClass": ["3-UL"],
    "vehicleMake": ["TOYOTA"],
    "vehicleMileage": ["23000"],
    "vehicleModel": ["CAMRY"],
    "vehicleSize": ["MID-SIZE CAR"],
    "vehicleTrim": ["PREMIUM"],
    "vehicleType": ["C"],
    "vehicleVIN": ["2345RTY9876YT34566"],
    "vehicleYear": ["2014"]
}
EOF
else
  echo "ERROR: Unknown tenant: $TENANT"
  exit 1
fi

echo "TENANT: $(echo ${TENANT} | tr a-z A-Z)"
echo "CDARID: ${CDARID}"
echo "TASKID: ${TASKID}"
