#!/usr/bin/env bash

# inherit from caller/sourcer if already defined.
BIN_DIR=${BIN_DIR:-$(dirname "$(readlink -f "$0")")}

TOTAL_LASTNAMES=$(wc -l ${BIN_DIR}/lib/names.txt|tr -s " " | cut -d\  -f1)
TOTAL_FIRSTNAMES=$(wc -l ${BIN_DIR}/lib/first-names.txt|tr -s " " | cut -d\  -f1)
TOTAL_MIDDLENAMES=$(wc -l ${BIN_DIR}/lib/middle-names.txt|tr -s " " | cut -d\  -f1)
TOTAL_PLACES=$(wc -l ${BIN_DIR}/lib/places.txt|tr -s " "|cut -d\  -f1)

# What's the AgreementNo length?
AGREEMENT_NO_LEN=8

function generate_string() {
    local len=${1:-16}
    cat /dev/urandom | LC_CTYPE=C tr -dc 'A-Za-z0-9' | fold -w ${len} | head -n 1
}

function generate_hexstr() {
    local len=${1:-16}
    cat /dev/urandom | LC_CTYPE=C tr -dc 'a-f0-9' | fold -w ${len} | head -n 1
}

# generate a case number
function generate_case_no() {
    echo "$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)"
}

# generate an activity number
function generate_activity_no() {
    echo "$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)-$(generate_hexstr 4)"
}

function generate_form_delivery_channel() {
    [[ $(expr ${RANDOM} % 2) == 0 ]] && echo "EMail" ||  echo "Print Central"
}

# generate a middle name,
function generate_middle_name() {
    local NAME=$(( ( RANDOM % $TOTAL_MIDDLENAMES )  + 1 ))
    echo "$(sed $NAME'q;d' ${BIN_DIR}/lib/middle-names.txt)"
}

# generate a first name
function generate_first_name() {
    local FNAME=$(( ( RANDOM % $TOTAL_FIRSTNAMES )  + 1 ))
    echo "$(sed $FNAME'q;d' ${BIN_DIR}/lib/first-names.txt)"
}

# generate a last name
function generate_last_name() {
    local LNAME=$(( ( RANDOM % $TOTAL_LASTNAMES )  + 1 ))
    echo "$(sed $LNAME'q;d' ${BIN_DIR}/lib/names.txt)"
}

# generate first and last name separated by space.
function generate_first_last_name() {
    local FNAME=$(( ( RANDOM % $TOTAL_FIRSTNAMES )  + 1 ))
    local LNAME=$(( ( RANDOM % $TOTAL_LASTNAMES )  + 1 ))
    echo "$(sed $FNAME'q;d' ${BIN_DIR}/lib/first-names.txt) $(sed $LNAME'q;d' ${BIN_DIR}/lib/names.txt)"
}

# roll a dice and 50% of the time output a middlename property.
# ..that is the key:value for a json document.
function maybe_generate_middle_name_property() {
    [[ $(( ( RANDOM % 2 ) )) = 1 ]] && {
        echo "\"middleName\" : \"$(generate_middle_name)\","
    }
}

# generate a domain name
function generate_domain_name() {
    local PLACE=$(( ( RANDOM % $TOTAL_PLACES )  + 1 ))
    echo "$(sed $PLACE'q;d' ${BIN_DIR}/lib/places.txt | tr 'A-Z' 'a-z').com"
}

# generate an email address, optionally from first and last names
# ..passed-in as arguments.
function generate_email() {
    local FN=${1:-$(generate_first_name)}
    local LN=${2:-$(generate_last_name)}
    FN=$(echo $FN|tr 'A-Z' 'a-z')
    LN=$(echo $LN|tr 'A-Z' 'a-z')
    echo "${FN}.${LN}@$(generate_domain_name)"
}

# generate a US phone number
function generate_phone_no() {
    printf "(%03d) %03d-%04d" $((RANDOM % 999)) $((RANDOM % 999)) $((RANDOM % 9999))
}

# generate a line1 address (street no + street)
# TODO: improve this
function generate_address_line_one() {
    local ROAD="St Rd Ave Blvd Ct Pkwy Pl Way xxx"
    local IDX=$(( ( RANDOM % $(echo ${ROAD}|wc -w) )  + 1 ))
    echo "$((RANDOM % 99999)) $(generate_middle_name) $(echo $ROAD|cut -d\  -f${IDX}|sed 's/xxx//g')" | sed 's/[[:blank:]]*$//g'
}

# TODO: implement this
function maybe_generate_address_line_two_property() {
    echo "\"addressLine2\" : \"\","
}

# generate a city; 50% of the time, make it a two-word city.
function generate_city () {
    local PLACE=$(( ( RANDOM % $TOTAL_PLACES )  + 1 ))
    local CITY=$(sed $PLACE'q;d' ${BIN_DIR}/lib/places.txt)

    [[ $(( ( RANDOM % 2 ) )) = 1 ]] && {
        PLACE=$(( ( RANDOM % $TOTAL_PLACES )  + 1 ))
        CITY="${CITY} $(sed $PLACE'q;d' ${BIN_DIR}/lib/places.txt)"
    }
    echo ${CITY}
}

# generate a US state
function generate_state () {
    local IDX=$(( ( RANDOM % 50 )  + 1 ))
    sed $IDX'q;d'<<-EOF | cut -d- -f2
Alabama-AL
Alaska-AK
Arizona-AZ
Arkansas-AR
California-CA
Colorado-CO
Connecticut-CT
Delaware-DE
Florida-FL
Georgia-GA
Hawaii-HI
Idaho-ID
Illinois-IL
Indiana-IN
Iowa-IA
Kansas-KS
Kentucky-KY
Louisiana-LA
Maine-ME
Maryland-MD
Massachusetts-MA
Michigan-MI
Minnesota-MN
Mississippi-MS
Missouri-MO
Montana-MT
Nebraska-NE
Nevada-NV
New Hampshire-NH
New Jersey-NJ
New Mexico-NM
New York-NY
North Carolina-NC
North Dakota-ND
Ohio-OH
Oklahoma-OK
Oregon-OR
Pennsylvania-PA
Rhode Island-RI
South Carolina-SC
South Dakota-SD
Tennessee-TN
Texas-TX
Utah-UT
Vermont-VT
Virginia-VA
Washington-WA
West Virginia-WV
Wisconsin-WI
Wyoming-WY
EOF

#American Samoa-AS
#District of Columbia-DC
#Federated States of Micronesia-FM
#Guam-GU
#Marshall Islands-MH
#Northern Mariana Islands-MP
#Palau-PW
#Puerto Rico-PR
#Virgin Islands-VI
}

# generate a US zip code
function generate_zipcode() {
    echo "$((10000 + RANDOM % 99999))"
}

# generate a date-of-birth; at least 17 years old
function generate_dob() {
    local AGE=$(( RANDOM % 100 ))
    local YEAR=$(($(date +%Y) - 17 - $AGE))
    local MONTH=$(( RANDOM % 12  + 1))
    local DAY=$(( RANDOM % 28  + 1))
    printf "${YEAR}-%02d-%02d" $MONTH $DAY
}

# generate an SSN
function generate_ssn() {
    printf "%03d-%02d-%04d" $(( RANDOM % 999)) $(( RANDOM % 99)) $(( RANDOM % 9999))
}

function generate_ssn_last6() {
    printf "%02d%04d" $(( RANDOM % 99)) $(( RANDOM % 9999))
}

# generate an account number
# TODO: improve this
function generate_acctno() {
    generate_string | tr 'a-z' 'A-Z'
}

# generate an application number
# TODO: improve this
function generate_applno() {
    generate_string | tr 'a-z' 'A-Z'
}

# generate an agreement number
# TODO: improve this
function generate_agreeno() {
    generate_string ${AGREEMENT_NO_LEN} | tr 'a-z' 'A-Z'
}

# generate a VIN
# TODO: improve this
function generate_vin() {
    generate_string 17 | tr 'a-z' 'A-Z'
}

function generate_vin_last8() {
    generate_string 8 | tr 'a-z' 'A-Z'
}
