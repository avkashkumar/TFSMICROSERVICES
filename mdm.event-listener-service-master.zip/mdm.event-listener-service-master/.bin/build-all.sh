#!/bin/bash

function parallel () {
	while read line ; do
	  $1 "$line"
	done
}

function build_lib () {
	local dir=$1
	echo "  building $(basename $dir)"
	cd ${dir}
	mvn ${CLEAN:+clean}  package install 2>&1> /dev/null || echo "$(basename ${dir}) failed"
	cd - 2>&1>/dev/null
}

function build_img () {
	local dir=$1
	cd ${dir}
	mvn ${CLEAN:+clean}  package dockerfile:build -DskipTests 2>&1> /dev/null || echo "$(basename ${dir}) failed"
	cd - 2>&1>/dev/null
}

function build_app () {
	local dir=$1
	cd ${dir}
	mvn ${CLEAN:+clean}  package -DskipTests 2>&1> /dev/null || echo "$(basename ${dir}) failed"
	cd - 2>&1>/dev/null
}

function build_libs () {
	# build common libs
	echo "building libs.."
	while read line ; do
		build_lib $line
	done<<-EOF
lib/common
lib/event
lib/multitenant
EOF
}

function pbuild_imgs () {
	# build docker images
	echo "building dockerized microservices.."
	parallel build_img {} <<-EOF
microservices/tenant
microservices/cdar
microservices/fulfillment
microservices/ccpa
microservices/forwarder
EOF
}

function pbuild_apps () {
	# build docker images
	echo "building microservices.."
#	parallel build_app {} <<-EOF
#microservices/notification
#EOF
#microservices/cdar
}

export -f build_lib
export -f build_img
export -f build_app
export -f pbuild_imgs
export -f pbuild_apps

[[ $(uname) =~ CYGWIN* ]] || {
  # unset our faux parallel() when running in Linux
  unset -f parallel
}

SAVEDIR=$(pwd)

cd $(dirname "$0")/../../..

build_libs
pbuild_imgs &
pbuild_apps &
wait

cd "${SAVEDIR}"

