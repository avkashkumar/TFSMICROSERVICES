#!/usr/bin/env bash

function check_heroku () {
	git remote -v 2>&1 | tr -s $'\x9' ' ' | cut -d\  -f2 | egrep -q 'https://git.heroku.com/.*$' 2>&1>/dev/null
}

function current_repo () {
	git status | head -n1 | cut -d\  -f3
}

check_heroku || {
	echo "not connected to heroku!"
	exit 1
}

[ ! -d ./repo ] && {
	echo "creating local repo"
	mkdir -p ./repo
}

rsync -avr --delete ~/.m2/repository/tfs ./repo 
git commit -am "deploying to Heroku @ $(date '+%m-%d-%Y %H:%M:%S')"
git push heroku HEAD:master


