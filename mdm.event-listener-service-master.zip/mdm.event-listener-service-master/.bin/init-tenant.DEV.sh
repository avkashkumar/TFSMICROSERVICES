#!/usr/bin/env bash

TENANT_SERVICE_ENDPOINT=${TENANT_SERVICE_ENDPOINT:-http://localhost:8080}

echo "Populating: ${TENANT_SERVICE_ENDPOINT}"

# create TMCC tenant
TMCC_ID=$((curl -Lsi --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/tenant -d @-  | egrep -i '^Location' | sed 's/^.*\///g'| tr -d '\n\r' ) <<EOF
{   "name" : "Toyota Motor Credit Corporation"
    , "abbrevName":"TMCC"
    , "description":"Toyota Financial Services"
    , "headerValue":"TMCC"
    , "dbName":"tmcc"
}
EOF
)

# create TMIS tenant
TMIS_ID=$((curl -Lsi --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/tenant -d @-   | egrep -i '^Location'| sed 's/^.*\///g'| tr -d '\n\r'  ) <<-EOF
{ "name" : "Toyota Motors Insurance"
    , "abbrevName":"TMIS"
    , "description":"Toyota Motors Insurance Services"
    , "headerValue":"TMIS"
    , "dbName":"tmis"
}
EOF
)

# create MFS tenant
MFS_ID=$((curl -Lsi --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/tenant -d @-   | egrep -i '^Location'| sed 's/^.*\///g'| tr -d '\n\r'  ) <<-EOF
{ "name" : "Mazda Financial Services"
    , "abbrevName":"MFS"
    , "description":"Mazda Financial Services"
    , "headerValue":"MFS"
    , "dbName":"mfs"
}
EOF
)

# create MPP tenant
MPP_ID=$((curl -Lsi --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/tenant -d @-   | egrep -i '^Location'| sed 's/^.*\///g'| tr -d '\n\r'  ) <<-EOF
{ "name" : "Mazda Protection Products"
    , "abbrevName":"MPP"
    , "description":"Mazda Protection Products"
    , "headerValue":"MPP"
    , "dbName":"mpp"
}
EOF
)


# create synthetic AUTOFIN tenant
AUTOFIN_ID=$((curl -Lsi --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/tenant -d @-   | egrep -i '^Location'| sed 's/^.*\///g'| tr -d '\n\r'  ) <<-EOF
{ "name" : "AutoFin"
    , "abbrevName":"AUTOFIN"
    , "description":"autof.in"
    , "headerValue":"AUTOFIN"
    , "dbName":"autofin"
}
EOF
)

# create TMCC serviceproviders
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "tmcc-customer-bi"
  , "description" : "data warehouse"
  , "tenantId" : "${TMCC_ID}"
  , "scope" : "CUSTOMER"
  , "role" : "DATA_PROVIDER"
}
EOF

curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "tmcc-consumer-bi"
  , "description" : "data warehouse"
  , "tenantId" : "${TMCC_ID}"
  , "scope" : "CONSUMER"
  , "role" : "DATA_PROVIDER"
}
EOF

# create TMIS serviceproviders
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "tmis-customer-bi"
  , "description" : "data warehouse"
  , "tenantId" : "${TMIS_ID}"
  , "scope" : "CUSTOMER"
  , "role" : "DATA_PROVIDER"
}
EOF
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "tmis-consumer-bi"
  , "description" : "data warehouse"
  , "tenantId" : "${TMIS_ID}"
  , "scope" : "CONSUMER"
  , "role" : "DATA_PROVIDER"
}
EOF

# create MFS serviceproviders
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "mfs-customer-bi"
  , "description" : "MFS Customer Datalake"
  , "tenantId" : "${MFS_ID}"
  , "scope" : "CUSTOMER"
  , "role" : "DATA_PROVIDER"
}
EOF
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "mfs-consumer-bi"
  , "description" : "MFS Consumer Datalake"
  , "tenantId" : "${MFS_ID}"
  , "scope" : "CONSUMER"
  , "role" : "DATA_PROVIDER"
}
EOF

# create MPP serviceproviders
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "mpp-customer-bi"
  , "description" : "MPP Customer Datalake"
  , "tenantId" : "${MPP_ID}"
  , "scope" : "CUSTOMER"
  , "role" : "DATA_PROVIDER"
}
EOF
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "mpp-consumer-bi"
  , "description" : "MPP Consumer Datalake"
  , "tenantId" : "${MPP_ID}"
  , "scope" : "CONSUMER"
  , "role" : "DATA_PROVIDER"
}
EOF


# create AUTOFIN serviceproviders
curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "autofin-customer-bi"
  , "description" : "data warehouse"
  , "tenantId" : "${AUTOFIN_ID}"
  , "scope" : "CUSTOMER"
  , "role" : "DATA_PROVIDER"
}
EOF

curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "autofin-consumer-bi"
  , "description" : "data warehouse"
  , "tenantId" : "${AUTOFIN_ID}"
  , "scope" : "CONSUMER"
  , "role" : "DATA_PROVIDER"
}
EOF

curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "autofin-customer-onetrust"
  , "description" : "case manager"
  , "tenantId" : "${AUTOFIN_ID}"
  , "scope" : "CUSTOMER"
  , "role" : "DATA_PROVIDER"
}
EOF

curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "autofin-consumer-onetrust"
  , "description" : "case manager"
  , "tenantId" : "${AUTOFIN_ID}"
  , "scope" : "CONSUMER"
  , "role" : "DATA_PROVIDER"
}
EOF

curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "autofin-customer-aem"
  , "description" : "document generator"
  , "tenantId" : "${AUTOFIN_ID}"
  , "scope" : "CUSTOMER"
  , "role" : "DOC_GENERATOR"
}
EOF

curl --insecure --noproxy '*' -H 'Content-Type: application/json' ${TENANT_SERVICE_ENDPOINT}/serviceprovider -d @- <<EOF
{
  "name" : "autofin-consumer-aem"
  , "description" : "document generator"
  , "tenantId" : "${AUTOFIN_ID}"
  , "scope" : "CONSUMER"
  , "role" : "DOC_GENERATOR"
}
EOF
