package tfs.mdm.eventlistenerservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import tfs.dfs.multitenant.client.TenantServiceClient;

import java.util.Arrays;

@ComponentScan({ "tfs.mdm", "tfs.dfs"})
@SpringBootApplication(exclude = { MongoAutoConfiguration.class, MongoDataAutoConfiguration.class})
@EnableSwagger2
public class MdmEventListenerServiceApplication {

	private final Logger logger = LoggerFactory.getLogger(MdmEventListenerServiceApplication.class);
	@Autowired
	private TenantServiceClient tenantServiceClient;

	@Bean
	public Docket swagger() {
		return new Docket(DocumentationType.SWAGGER_2)
				.globalOperationParameters(
						Arrays.asList(new ParameterBuilder()
								.name("X-Tenant-Id")
								.description("Multi-tenancy header")
								.modelRef(new ModelRef("string"))
								.parameterType("header")
								.required(true)
								.build())
				)
				.select()
				.apis(RequestHandlerSelectors.any())
				.paths(PathSelectors.any())
				.build();
	}



	public static void main(String[] args) {
		SpringApplication.run(MdmEventListenerServiceApplication.class, args);
	}

}