package tfs.mdm.eventlistenerservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import tfs.dfs.common.event.CustomerInitiated;
import tfs.dfs.event.CustomerEventHandler;
import tfs.dfs.multitenant.CurrentTenantHolder;

@Configuration
public class MdmEventListenerCustomerEventHandler {

    private final Logger logger = LoggerFactory.getLogger(MdmEventListenerServiceApplication.class);
    @Bean
    public CustomerEventHandler customerEventHandler() {
        return new CustomerEventHandler() {
            public void handle(CustomerInitiated event) {
                logger.info("From Customer Event Handler : " + " Customer Id " + event.getCustomerId());
                logger.info("From Customer Event Handler: " + " Customer Name : " + event.getCustomerName());
                logger.info("From Customer Event Handler: " + " Customer UPM URI : " + event.getUpmURI());

                //Trying to do a "POST/customer-update" call to dummy-customer-microservice

                final String URI = "http://localhost:1313/customer-update";
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                RestTemplate restTemplate = new RestTemplate();
                HttpEntity<CustomerInitiated> entity = new HttpEntity<>(event, headers);
                restTemplate.exchange(URI, HttpMethod.POST, entity, CustomerInitiated.class);
                CurrentTenantHolder.remove();
            }

        };
    }
}

