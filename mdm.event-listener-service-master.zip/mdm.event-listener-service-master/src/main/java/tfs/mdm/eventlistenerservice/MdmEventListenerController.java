package tfs.mdm.eventlistenerservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tfs.dfs.common.event.CustomerInitiated;
import tfs.dfs.common.event.DfsEvent;
import tfs.dfs.common.model.customer.Customer;
import tfs.dfs.common.rest.ErrorResponseEntity;
import tfs.dfs.multitenant.CurrentTenantHolder;
import tfs.dfs.multitenant.dto.TenantConfiguration;

import javax.annotation.Resource;
import javax.validation.Valid;

@CrossOrigin
@RestController
public class MdmEventListenerController {
    private final static Logger logger = LoggerFactory.getLogger(MdmEventListenerController.class);
    @Resource(name = "multiTenantMongoTemplate")
    private MongoTemplate mongoTemplate;
    @Autowired
    private KafkaTemplate<String, DfsEvent> dfsEventKafkaTemplate;
    @Autowired
    private String topicId;
    @Value("${event.source.id}")
    private String eventSourceId;

    /**
     * This is rest endpoint for creating a sample customer.
     * MdmEventListenerService is not responsible for creating a customer,
     * this end point is just used for testing only until the UPM is ready
     * @param customer
     * @return
     */

    //creating new muti-tenant customer
    @PostMapping(value = "/customer", consumes = "application/json", produces = "application/json")
    public ResponseEntity create(@Valid @RequestBody Customer customer) {
        //defaults(customer);
        mongoTemplate.save(customer);
        // now, create a context and send the message to kafka
        broadcastCustomerInitiation(customer);
        final HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(customer.getCustomerId()).toUri());
        return new ResponseEntity(headers, HttpStatus.CREATED);
    }

    //Getting customer from customer collection using customer id.
    @GetMapping(value = "/customer/{id}", produces = "application/json")
    public ResponseEntity retrieveCustomer(@PathVariable(required = false) String id) {
        Customer customer = mongoTemplate.findById(id, Customer.class);
        if (customer == null) {
            return new ErrorResponseEntity(String.format("Customer with id %s was not found", id), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity(customer, HttpStatus.OK);
    }


    private void broadcastCustomerInitiation(Customer customer) {
        CustomerInitiated event = new CustomerInitiated();
        TenantConfiguration tc = CurrentTenantHolder.get();
        event.setCustomerId(customer.getCustomerId());
        event.setCustomerName(customer.getFirstName());
        event.setUpmURI("https://httpbin.org/{customerId}");
        dfsEventKafkaTemplate.send(topicId, event);
    }
}